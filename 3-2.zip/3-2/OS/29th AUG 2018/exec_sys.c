#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
main(const int argc,const char *argv[]){
        if(argc-1>3){
                printf("ARGUMENTS CANNOT BE MORE THAN 3.\n");
                exit(0);
        }
        //printf("%s",argv[1]);
        int pid = fork();
        if(pid==-1){
                printf("CHILD PROCESS CANNOT BE CREATED.\n");
                exit(0);
        }
        if(pid>0){
                wait(1);
                printf("CHILD PROCESS EXECUTION IS COMPLETED.\n");
                exit(1);
        }
        if(pid==0){
                printf("CHILD PROCESS EXECUTION BEGINS:-\n");
                if(execlp(argv[1],argv[1],argv[2],argv[3],NULL)<0){
                        printf("PLEASE CHECK THE ARGUMENTS PASSED\n");
                }
                exit(1);
        }
}
