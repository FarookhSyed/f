#include<stdio.h>
void mvt(int t1,int t2,int t3);
main(){
        int m_os,mem;
        int pgs_n;
        printf("Enter No.of process:");
        scanf("%d",&pgs_n);
        printf("Enter Memory size:");
        scanf("%d",&mem);
        printf("Enter Memory required by OS:");
        scanf("%d",&m_os);
        mvt(pgs_n,m_os,mem);
}
void mvt(int pgs_n,int m_os,int m_sz){
        int block,m_pg[pgs_n];
        int i,t=m_sz-m_os;
        printf("Enter the Memory required by Processes:");
        for(i=0;i<pgs_n;i++){
                scanf("%d",&m_pg[i]);
                if((t-m_pg[i])>0){
                        t-=m_pg[i];
                }
        }
        printf("Process\tMemory\n");
        for(i=0;i<pgs_n;i++){
                printf("%d\t%d\n",i+1,m_pg[i]);
        }
        printf("Total Enternal Fragmentation:%d\n",t);

}
