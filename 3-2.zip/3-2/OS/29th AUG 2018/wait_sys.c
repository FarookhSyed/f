#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>

main(){
        int pid,status=5;
        int i;
        pid = fork();

        if(pid==-1){
                printf("UNABLE TO CREATE A CHILD PROCESS.");
                exit(0);
        }
        else if(pid>0){
                wait(&status);
                printf("PARENT EXECUTION BEGINS:-\n");
                printf("EVEN NUMBERS ARE ");
                for(i=1;i<=10;i++){
                        if(i%2==0)
                                printf("%d ",i);
                }
                printf("\nPARENT EXECUTION COMPLETED.\n");
        }
        else{
                printf("CHILD EXECUTION BEGINS:-\n");
                printf("ODD NUMBERS ARE ");
                for(i=0;i<=10;i++){
                        if(i%2!=0)
                                printf("%d ",i);
                }
                printf("\nCHILD EXECUTION COMPLETED.\n");
                exit(status);
        }
        return 1;
}
