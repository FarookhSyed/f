#include<stdio.h>
void mft(int t1,int t2);
main(){
        int m_os;
        int pgs_n;
        printf("Enter No.of process:");
        scanf("%d",&pgs_n);
        printf("Enter Memory required by OS:");
        scanf("%d",&m_os);
        mft(pgs_n,m_os);
}
void mft(int pgs_n,int m_os){
        int m_sz,block,m_pg[pgs_n];
        int i,t=0;
        printf("Enter the Memory required by processes:");
        for(i=0;i<pgs_n;i++){
                scanf("%d",&m_pg[i]);
                if(m_pg[i]>t)
                        t = m_pg[i];
        }
        block = t;
        printf("Total Memory Required is %d\n",block*(pgs_n+1));
        printf("Process\tMemory\tFragmentation\n");t=0;
        for(i=0;i<pgs_n;i++){
                printf("%d\t%d\t%d\n",i+1,m_pg[i],block-m_pg[i]);
                t+=block-m_pg[i];
        }
        printf("Total Internal Fragmentation:%d\n",t);

}
