#include<stdlib.h>
#include<stdio.h>

main(){
        int i=0,t;
        while(1){
                printf("INPUT 1 TO EXIT:");
                scanf("%d",&t);

                if(t==1)
                        exit(1);
                printf("%d\n",++i);
        }
}
