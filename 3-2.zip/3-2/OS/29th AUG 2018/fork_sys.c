#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
main(){
        int pid1,pid2;

        pid1 = fork();

        if(pid1==-1){
                printf("CHILD-1 PROCESS IS NOT CREATED.\n");
                return 0;
        }
        else{
                printf("CHILD-1 PROCESS ID IS %d\n",getpid());
                printf("PARENT PROCESS ID IS %d\n",getppid());
        }

        pid2 = fork();

        if(pid2==-1){
                printf("CHILD-2 PROCESS IS NOT CREATED.\n");
                return 0;
        }
        else{
                printf("CHILD-2 PROCESS ID IS %d\n",getpid());
                printf("PARENT PROCESS ID IS %d\n",getppid());
        }
        return 1;
}
