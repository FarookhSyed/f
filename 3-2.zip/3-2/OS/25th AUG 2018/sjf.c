#include<stdio.h>

int sjf(int p);

main(){
        int p;

        printf("Enter No. of Process:");

        scanf("%d",&p);

        sjf(p);
}

int sjf(int p){
        int visits=0,visit[p],cputime=0;
        int a[p],b[p],c[p];
        int i=0,toexe[2],t=0;
        toexe[0]=0;
        toexe[1]=9999;
        printf("Enter Arrival Time of Processes %d:",p);
        for(i=0;i<p;i++){
                visit[i]=0;
                scanf("%d",&a[i]);
        }
        printf("Enter Burst Time of Processes %d:",p);
        for(i=0;i<p;i++){
                scanf("%d",&b[i]);
        }
        while(visits<p){
                t=1;
                for(i=0;i<p;i++){
                        //printf("1:%d\t",toexe[1]);
                        if(visit[i]==0 && a[i]<=cputime){
                                //printf("2:%d\t",toexe[1]);
                                if(toexe[1]>b[i]){
                                        //printf("3:%d\n",toexe[1]);
                                        toexe[0]=i;
                                        toexe[1]=b[i];
                                        t=0;
                                }
                        }
                        //printf("\n");
                }
                i = toexe[0];
                if(t==0){
                        cputime+=b[i];
                        c[i]=cputime;
                        visits+=1;
                        visit[i]=1;
                }
                else{
                        cputime+=1;
                }
                toexe[1]=9999;

        }
        printf("P\tAT\tBT\tCT\tTAT\tWT\n");
        for(i=0;i<p;i++){
                printf("P%d\t%d\t%d\t%d\t%d\t%d\n",i+1,a[i],b[i],c[i],c[i]-a[i],c[i]-a[i]-b[i]);
        }
}

