#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
int i;
void *thread_fun_1(void *temp){
        for(;i<10;i++){
                printf("\n1-i=%d",i);
                sleep(2);
        }
        printf("\nDONE AT THREAD-1");
        return NULL;

}

void *thread_fun_2(void *temp){
        for(;i<20;i++){
                sleep(1);
                printf("\n2-i=%d",i);
        }
        printf("\nDONE AT THREAD-2");
        return NULL;
}

int main(){
        pthread_t thread_id;
        i = 0;
        if((pthread_create(&thread_id,NULL,thread_fun_1,NULL))){
                printf("UNABLE TO CREATE THREAD-1\n");
                printf("EXITING...");
                exit(0);
        }
        sleep(1);
        if(pthread_create(&thread_id,NULL,thread_fun_2,NULL)){
                printf("UNABLE TO CREATE THREAD-2\n");
                printf("EXITING...");
                exit(0);
        }
        pthread_join(thread_id,NULL);
        exit(1);
}
