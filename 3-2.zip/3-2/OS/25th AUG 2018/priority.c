#include<stdio.h>

int priority(int p);

main(){
        int p;

        printf("Enter No. of Process:");

        scanf("%d",&p);

        priority(p);
}

int priority(int p){
        int visits=0,visit[p],cputime=0;
        int a[p],b[p],c[p],pri[p];
        int i=0,toexe[2],t=0;
        toexe[0]=0;
        toexe[1]=9999;
        printf("Enter Arrival Time of Processes %d:",p);
        for(i=0;i<p;i++){
                visit[i]=0;
                scanf("%d",&a[i]);
        }
        printf("Enter Burst Time of Processes %d:",p);
        for(i=0;i<p;i++){
                scanf("%d",&b[i]);
        }
        printf("Enter Priorities of Processes %d:",p);
        for(i=0;i<p;i++){
                scanf("%d",&pri[i]);
        }
        while(visits<p){
                t=1;
                for(i=0;i<p;i++){
                        if(visit[i]==0 && a[i]<=cputime){
                                if(toexe[1]>pri[i]){
                                        toexe[0]=i;
                                        toexe[1]=pri[i];
                                        t=0;
                                }
                        }
                }
                i = toexe[0];
                if(t==0){
                        cputime+=b[i];
                        c[i]=cputime;
                        visits+=1;
                        visit[i]=1;
                }
                else{
                        cputime+=1;
                }
                toexe[1]=9999;

        }
        printf("P\tPRI\tAT\tBT\tCT\tTAT\tWT\n");
        int ca=0,ta=0,wa=0;
        for(i=0;i<p;i++){
                ca+=c[i];
                ta+=(c[i]-a[i]);
                wa+=(c[i]-a[i]-b[i]);
                printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\n",i+1,pri[i],a[i],b[i],c[i],c[i]-a[i],c[i]-a[i]-b[i]);
        }
	printf("Tot:\t\t\t\t%d\t%d\t%d\n",ca,ta,wa);
        float x = p*1.0;
        printf("Avg:\t\t\t\t%.2f\t%.2f\t%.2f\n",ca/x,ta/x,wa/x);
}
