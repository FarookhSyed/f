#include<stdio.h>

int rr(int p);

main (){
        int p;

        printf("Enter No. of Process:");

        scanf("%d",&p);

        rr(p);

}

int rr(int p){
        int visit[p],cputime=0,visits=0,s;
        int a[p],b[p],c[p],e[p];
        int t = 0,i,l;
        printf("Enter Arrival Time of %d processes:",p);
        for(i=0;i<p;i++){
                visit[i]=0;
                e[i] = 0;
                scanf("%d",&a[i]);
        }
        printf("Enter Burst Time of %d processes:",p);
        for(i=0;i<p;i++){
                scanf("%d",&b[i]);
        }
        printf("Enter Time Slice:");
        scanf("%d",&s);
        while(visits<p){
                l = 0;
                for(i=0;i<p;i++){
                        if(visit[i]==0 && a[i]<=cputime){
                                t=e[i]+s;
                                if(t>=b[i]){
                                        visit[i] = 1;
                                        t = t-b[i];
                                        t = s-t;
                                        cputime+=t;
                                        c[i] = cputime;
                                        visits+=1;
                                }
                                else{
                                        cputime += s;
                                        e[i]+=s;
                                }
                                l=1;
                        }

                }
                if(l==0){
                        cputime+=1;
                }
        }
        printf("Process\tAT\tBT\tCT\tTAT\tWT\n");
        int ca=0,ta=0,wa=0;
        for(i=0;i<p;i++){
                ca+=c[i];
                ta+=(c[i]-a[i]);
                wa+=(c[i]-a[i]-b[i]);
                printf("P%d\t%d\t%d\t%d\t%d\t%d\n",i+1,a[i],b[i],c[i],c[i]-a[i],c[i]-a[i]-b[i]);
        }
        printf("Tot:\t\t\t%d\t%d\t%d\n",ca,ta,wa);
        float x = p*1.0;
        printf("Avg:\t\t\t%.2f\t%.2f\t%.2f\n",ca/x,ta/x,wa/x);

}
