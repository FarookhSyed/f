#include<stdio.h>

int fcfs(int p);

main (){
        int p;

        printf("Enter No. of Process:");

        scanf("%d",&p);

        fcfs(p);

}

int fcfs(int p){
        int visit[p],cputime=0,visits=0;
        int a[p],b[p],c[p];
        int t = 0,i;
        printf("Enter Arrival Time of %d processes:",p);
        for(i=0;i<p;i++){
                visit[i]=0;
                scanf("%d",&a[i]);
        }
        printf("Enter Burst Time of %d processes:",p);
        for(i=0;i<p;i++){
                scanf("%d",&b[i]);
        }
        while(visits<p){
                t=0;
                for(i=0;i<p;i++){
                        if(a[i]<=cputime){
                                if(visit[i]==0){

                                        visit[i] = 1;
                                        t = 1;
                                        cputime+=b[i];
                                        c[i] = cputime;
                                        visits+=1;
                                }
                        }

                }

        }
        if(a==0){
                cputime+=1;
        }
        printf("Process\tAT\tBT\tCT\tTAT\tWT\n");
        for(i=0;i<p;i++){

                printf("P%d\t%d\t%d\t%d\t%d\t%d\n",i+1,a[i],b[i],c[i],c[i]-a[i],c[i]-a[i]-b[i]);
        }

}
