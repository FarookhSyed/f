#include<stdio.h>
int fifo(int t1,int t2);
main(){
        int pgsz,seqsz;
        printf("Enter the page size:");
        scanf("%d",&pgsz);
        printf("Enter the sequence size:");
        scanf("%d",&seqsz);
        fifo(pgsz,seqsz);
}

int fifo(int pgsz,int seqsz){
        int i,j=0,pg[pgsz],seq[seqsz],pgf=0;
        for(i=0;i<pgsz;i++)
                pg[i] = -1;
        printf("Enter the sequence:");
        for(i=0;i<seqsz;i++) scanf("%d",&seq[i]);
        for(i=0;i<seqsz;i++){
                if(pg[j] == -1 || pg[j] != seq[i]){
                        pg[j] = seq[i];
                        pgf++;
                }
                j = (j+1)%pgsz;
        }
        printf("Page Faults are %d\n",pgf);
        printf("Page Hits are %d\n",seqsz-pgf);
}
