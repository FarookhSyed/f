#include<stdio.h>
int lru(int t1,int t2);
main(){
        int pgsz,seqsz;
        printf("Enter the page size:");
        scanf("%d",&pgsz);
        printf("Enter the sequence size:");
        scanf("%d",&seqsz);
        lru(pgsz,seqsz);
}

int lru(int pgsz,int seqsz){
        int i,j=0,k=0,pg[pgsz],seq[seqsz],pgf=0,exist;
        for(i=0;i<pgsz;i++)
                pg[i] = -1;
        printf("Enter the sequence:");
        for(i=0;i<seqsz;i++) scanf("%d",&seq[i]);
        for(i=0;i<seqsz;i++){
                exist = 0;
                for(j=0;j<pgsz;j++){
                        if(seq[i] == pg[j]){
                                exist = 1;
                                break;
                        }
                        if(i>=pgsz)
                                if(seq[i-pgsz] == pg[j]){
                                        exist=-1;
                                        break;
                                }
                }
                if(exist == 1) continue;
                else if(exist==-1) pg[j] = seq[i];
                else pg[k]=  seq[i];
                pgf++;
                k = (k+1)%pgsz;
                for(j=0;j<pgsz;j++)
                        printf("%d\t",pg[j]);
                printf("\n");
        }
        printf("Page Faults are %d\n",pgf);
        printf("Page Hits are %d\n",seqsz-pgf);
}
