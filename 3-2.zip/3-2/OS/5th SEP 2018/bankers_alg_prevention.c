#include<stdio.h>
int i,j;
void test_bench(int t1,int t2);
void bankers_alg(int t1,int t2,int t3[t2],int t4[t1][t2],int t5[t1][t2],int t6[t1][t2],int t7[t2]);
main(){
        int p,r;
        printf("Enter No.of Processes:");
        scanf("%d",&p);
        printf("Enter No.of of Resources:");
        scanf("%d",&r);
        test_bench(p,r);
}

void test_bench(int p,int r){
        int ri[r],ra[r],ri_max[p][r],ri_alloc[p][r],ri_need[p][r];
        printf("Enter No.of Instances in each resource:");
        for(i=0;i<r;i++)
                scanf("%d",&ri[i]);
        for(i=0;i<p;i++){
                printf("Enter the max resources required for p%d:",i);
                for(j=0;j<r;j++)
                        scanf("%d",&ri_max[i][j]);
        }
        for(i=0;i<p;i++){
                printf("Enter the allocated resources for p%d:",i);
                for(j=0;j<r;j++)
                        scanf("%d",&ri_alloc[i][j]);
        }
        for(j=0;j<r;j++)
                ra[j] = ri[j];
        for(i=0;i<p;i++){
                for(j=0;j<r;j++){
                        ri_need[i][j] = ri_max[i][j]-ri_alloc[i][j];
                        ra[j] -= ri_alloc[i][j];
                }
        }
        bankers_alg(p,r,ri,ri_max,ri_alloc,ri_need,ra);
}
void bankers_alg(int p,int r,int ri[r],int p_ri_max[p][r],int p_ri_alloc[p][r],int p_ri_need[p][r],int ra[r]){
        int visit[p],c,visits=0,stp;
        for(i=0;i<p;i++) visit[i] = 0;
        printf("The Safe Sequence is ");
        while(visits<p){
                c = -1;
                for(i=0;i<p;i++){
                        if(visit[i]==1)
                                continue;
                        stp = 0;
                        for(j=0;j<r;j++){
                                //printf("%d->%d>%d\t",i,p_ri_need[i][j],ra[j]);
                                if(p_ri_need[i][j]>ra[j]){
                                        stp = 1;
                                        break;
                                }
                        }
                        if(stp==1)
                                continue;
                        //printf("%d\t",i);
                        for(j=0;j<r;j++){
                                //printf("%d+%d ",ra[j],p_ri_alloc[i][j]);
                                ra[j] += p_ri_alloc[i][j];
                        }
                        visit[i] = 1;
                        visits++;
                        c++;
                        printf("%d ",i);
                }
                if(c==-1)
                        break;
        }
        printf("\nThe processes not in safe sequence are");
        for(i=0;i<p;i++){
                if(visit[i]==0){
                        printf("%d ",i);
                }
        }

}
