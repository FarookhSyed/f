#include<stdio.h>
int i,j;
void lfu(int t1,int t2);
int find(int t1,int sz,int t2[sz]);
main(){
        int frmsz,seqsz;
        printf("Enter the Frame size:");
        scanf("%d",&frmsz);
        printf("Enter Sequence Size:");
        scanf("%d",&seqsz);
        lfu(frmsz,seqsz);
}
int find(int seqele,int seqsz,int keys[seqsz]){
        int i;
        for(i=0;i<seqsz;i++){
                if(keys[i] == seqele)
                        return i;
        }
        return -1;
}

void lfu(int frmsz,int seqsz){
        int keys[seqsz],vals[seqsz];
        printf("Enter the Elements :-");
        int seq[seqsz];
        for(i=0;i<seqsz;i++){
                scanf("%d",&seq[i]);
        }
        /*for(i=0;i<seqsz;i++){
                printf("%d ",seq[i]);
        }*/
        int frm[frmsz];
        for(i=0;i<frmsz;i++)
                frm[i] = -1;
        int itr = -1,counter = 0,count = -1;
        int pos = 0,exist = 0,prev = -1,cmmn[frmsz];
        int pgf = 0;
        while(itr < seqsz){
                printf("\n");
                for(i=0;i<frmsz;i++){
                        printf("%d ",frm[i]);
                }
                printf("\n");
                itr++;count = -1;
                exist = -1;prev = -1;
                printf("%d\n",seq[itr]);
                for(i=0;i<frmsz;i++){
                        if(frm[i]==-1){
                                frm[i] = seq[itr];
                                pgf++;
                                keys[counter] = seq[itr];
                                vals[counter++] = 1;
                                exist = 0;
                                break;
                        }
                        else if(frm[i] == seq[itr]){
                                exist = find(seq[itr],seqsz,keys);
                                vals[exist]++;
                               printf("%d->%d ",frm[i],vals[exist]);
                                exist = 0;
                                break;
                        }
                }//printf("%d==%d ",seq[itr],frm[i]);
                if(exist == 0){
                        continue;
                }
                printf("cmmn:- ");
                for(i=0;i<frmsz;i++){
                        exist = find(frm[i],seqsz,keys);
                        if(prev > vals[exist] || prev == -1){
                                prev = vals[exist];
                                cmmn[0] = frm[i];
                                count = 1;
                        }
                        else if(prev == vals[exist]){
                                cmmn[count] = frm[i];
                                count++;
                        }
                        printf("%d:%d->%d ",i,frm[i],vals[exist]);
                }
                if(count>1){
                        prev = 0;
                        for(i=itr-1;i>=0;i--){
                                for(j=0;j<count;j++){
                                        if(seq[i] == cmmn[j] && exist != j){
                                                exist = j;
                                                prev++;
                                        }
                                        if(prev == count-1)
                                                break;
                                }
                        }
                        j = exist;
                        for(i=0;i<frmsz;i++){
                                if(frm[i] == cmmn[j]){
                                        frm[i] = seq[itr];
                                        break;
                                }
                        }

                }
                else{
                        for(i=0;i<frmsz;i++){
                                if(frm[i] == cmmn[i]){
                                        frm[i] = seq[itr];
                                        break;
                                }
                        }
                }
                exist = find(frm[i],seqsz,keys);
                if(exist!=-1){
                        vals[exist] = 1;
                }
                else{
                        keys[counter] = seq[itr];
                        vals[counter++] = 1;
                }

        }
}
