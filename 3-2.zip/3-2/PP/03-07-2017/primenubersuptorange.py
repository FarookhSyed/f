n=2000000
x=2;r=0;c=0
while(x<=n):
    for i in range(1,x+1):
        if(x%i==0):
            c=c+1
    if(c==2):
        r=r+x
        print(x)
    x=x+1
    c=0
print("Sum = "+str(r))
