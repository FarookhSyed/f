a=1;b=1
n=4000000
x=1;r=0;s=0
#print(a);print(b)
while(r<=n):
    r=a+b
    a=b
    b=r
    #print(r)
    if(r%2==0):
        s=s+r
print("sum = "+str(s))
        
        
