stringx = str(input("Enter the String in quotes:"))#"Program to Spilt and join a String"
splitstring = stringx.split(" ")
print(splitstring)
joinstring = "_".join(splitstring)
print(joinstring)
