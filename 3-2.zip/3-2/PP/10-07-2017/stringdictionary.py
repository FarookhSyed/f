stringx = str(input("Enter the String in quotes:"))#"Program to Count number of Characters in String and place them in Dictionary."
count=0
for l in stringx:
    count=count+1
print("Length of the String:"+str(count))
d=dict()
for letter in stringx:
    if letter in d.keys():
        d[letter] = d[letter]+1
    else:
        d[letter]=1
print(d)
