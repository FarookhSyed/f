l1=[1,2,3,4]
l2=["Red","black","Green","Yellow"]
print(dict(zip(l1,l2)))
