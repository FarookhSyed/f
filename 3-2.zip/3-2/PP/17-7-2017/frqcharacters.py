import string
n="comblidic.py"
#n=str(input("Enter File Name with Extension:"))
file=open(n)
data=file.read()
words=string.split(data)
lines=data.split("\n")
character=0
for i in data:
    character=character+1
print("Number of Characters = "+str(character))
d=dict()
for l in data:
    if l in d.keys():
        d[l]=d[l]+1
    else:
        d[l]=1
print(d)
line=lines[0]
t=0
if(line=="#include<stdio.h>"):
    print("C program File")
else:
    for c in range(len(data)):
        if(data[c]=='p' and data[c+1]=='r' and data[c+2]=='i' and data[c+3]=='n' and data[c+4]=='t' and data[c+5]=='('):
            print("Python File")
            t=1
            break
if(t==0):
    print("Text file")
        

