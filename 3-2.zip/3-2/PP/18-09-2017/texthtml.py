import requests
url=str(input("Enter the Url:"))
response=requests.get(url)
txt=response.text
print txt
