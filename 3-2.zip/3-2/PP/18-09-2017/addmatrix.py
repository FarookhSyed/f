from __future__ import print_function
def ADDMATRIX():
    mat=[]
    print("ENTER MATRIX-1 SIZE:-")
    mat1=[]
    row1=input("Enter Row Size of Matrix:")
    col1=input("Enter Column Size of Matrix:")
    print("ENTER MATRIX-2 SIZE:-")
    mat2=[]
    row2=input("Enter Row Size of Matrix:")
    col2=input("Enter Column Size of Matrix:")
    if(row1==row2 and col1==col2):
        print("ENTER MATRIX-1 ELEMENTS")
        mat1=[[input("Enter Element:") for j in range(col1)]for i in range(row2)]
        print("ENTER MATRIX-2 ELEMENTS")
        mat2=[[input("Enter Element:") for j in range(col1)]for i in range(row2)]
        mat=[[0 for j in range(col1)]for i in range(row2)]
        print("ADDTION OF GIVEN TWO MATRICES:-")
        for i in range(row1):
            for j in range(col2):
                mat[i][j]=mat1[i][j]+mat2[i][j]
                print(mat[i][j],end=' ')
            print()
        return mat
    else:
        print("Only Square Matrices are Allowed.")
        return 0
ADDMATRIX()
