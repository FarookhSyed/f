from __future__ import print_function
def MULTIPLYMATRIX():
    mat=[]
    print("ENTER MATRIX-1 SIZE:-")
    mat1=[]
    row1=input("Enter Row Size of Matrix:")
    col1=input("Enter Column Size of Matrix:")
    print("ENTER MATRIX-2 SIZE:-")
    mat2=[]
    row2=input("Enter Row Size of Matrix:")
    col2=input("Enter Column Size of Matrix:")
    if(row1==col2 and col1==row2):
        print("ENTER MATRIX-1 ELEMENTS")
        mat1=[[input("Enter Element:") for j in range(col1)]for i in range(row1)]
        print("ENTER MATRIX-2 ELEMENTS")
        mat2=[[input("Enter Element:") for j in range(col2)]for i in range(row2)]
        mat=[[0 for j in range(col2)]for i in range(row1)]
        print("MULTIPLICATION OF GIVEN TWO MATRICES:-")
        for i in range(row1):#Rows in mat1
            x=0
            for j in range(col2):#Column in mat1
                for k in range(col1):
                    x=x+mat1[i][k]*mat2[k][j]
                mat[i][j]=x
                x=0
                print(mat[i][j],end=' ')
            print()
        return mat
    else:
        print("GIVEN MATRIX SIZES are NOT Allowed.")
        return 0
MULTIPLYMATRIX()
