from __future__ import print_function
def MATRIX():
    mat=[]
    row=input("Enter Row Size of Matrix:")
    col=input("Enter Column Size of Matrix:")
    mat=[[input("Enter Element:") for j in range(col)]for i in range(row)]
    for i in mat:
        for j in i:
            print(j,end=' ')
        print()
    return mat
MATRIX()
