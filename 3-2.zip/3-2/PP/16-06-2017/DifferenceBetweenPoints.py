x1=input("Enter value of point X1,Y1:")
y1=input()
x2=input("Enter value of point X2,Y2:")
y2=input()

x=x2-x1
y=y2-y1

x=x**x
y=y**y

z=float((x+y)**0.5)

print "Distance between Two Points is "+str(z)
