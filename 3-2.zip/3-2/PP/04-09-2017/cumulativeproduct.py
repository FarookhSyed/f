def cumulative_product(l):
    print("Given List : "+str(l))
    l1=[]
    prod=1
    for i in l:
        prod=prod*i
        l1.append(prod)
    return l1

n=input("Enter Length of List:")
l=[]
for i in range(n):
    x=input("Enter Element:")
    l.append(x)
print("Cumulative Product of List : "+str(cumulative_product(l)))
