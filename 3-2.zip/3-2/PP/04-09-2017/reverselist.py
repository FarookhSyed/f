def reverse(l):
    print("Given List : "+str(l))
    l1=[]
    for i in range(len(l)):
        l1.append(l[-(i+1)])
    return l1

n=input("Enter Length of List:")
l=[]
for i in range(n):
    x=input("Enter Element:")
    l.append(x)
print("Reversed List : "+str(reverse(l)))
