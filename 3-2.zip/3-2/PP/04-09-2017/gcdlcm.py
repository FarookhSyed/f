def gcd(a,b):
    #if(a%b==0):
            #return b
        #else:
            #gcd(b,a%b)
    
        #OR
    
    #Eucldian Algorithm
    while(b):
        a,b=b,a%b
    return a
def lcm(a,b):
    return (a*b)/gcd(a,b)

a=input("Enter the Value(a):")
b=input("Enter the Value(b):")
print("Greatest Common Divisor is "+str(gcd(a,b)))
print("Least Common Multiple is "+str(lcm(a,b)))



