while(1):
    ch=input("Enter 1-29 to run a Script and zero to break:")
    if(ch==0):
        break
    elif(ch==1):
        print("Program to print Hello World")
        print("Hello World")
    elif(ch==2):
        print("Program to Find Square Root of a Number")
        sq=input("Enter a Number to Find Square Root:")
        sq=sq**0.5
        print("Result="+str(sq))
    elif(ch==3):
        print("Program to Find Sum of 2 Numbers")
        a=input("Enter Numeric Value:")
        b=input("Enter Numeric Value:")
        c=a+b
        print("Sum = "+str(c))
    elif(ch==4):
        print("Program to Find Area of a Triangle")
        a=input("Enter a,b,c side values of Triangle:")
        b=input();c=input()
        s=(a+b+c)/2
        area=(s*(s-a)*(s-b)*(s-c))**0.2
        print("Area of Triangle is "+str(area))
    elif(ch==5):
        print("Program to Solve Quadratic Equation")
        a=input("Enter a,b,c values from equation a(x**2)+bx+c :")
        b=input();c=input()
        r=(b**2)-4*a*c
        r1=((-b)+r)/2*a
        r2=((-b)-r)/2*a
        print("x="+str(r1)+" or "+str(r2))
    elif(ch==6):
        print("Program to Swap two Numbers")
        a=input("Enter Numeric Value:")
        b=input("Enter Numeric Value:")
        t=a;a=b;b=t
        print("Number after Swap a="+str(a)+" b="+str(b))
    elif(ch==7):
        print("Program to Print a Random Number")
        print("Program not yet coded")
    elif(ch==8):
        print("Program to Convert Km to Miles")
        kms=input("Enter Kilometers:")
        miles=kms*0.632
        print("Miles = "+str(miles))
    elif(ch==9):
        print("Program to Convert Temperature from C to F")
        c=input("Enter Temperature in C:")
        f=((9/5)*c)+32
        print("Temperature in F is "+str(f))
    elif(ch==10):
        print("Program to Find given Number is Positive or Negative")
        x=input("Enter Numeric Value:")
        if(x==0):
            print("Zero")
        elif(x>0):
            print("Positive Number")
        else:
            print("Negative Number")
    elif(ch==11):
        print("Program to Find if the Given Number is Even or Odd")
        x=input("Enter a Numeric Value:")
        if(x%2==0):
            print("Given Number is Even")
        else:
            print("Given Number is Odd")
    elif(ch==12):
        print("Program to Find given year is a Leap year or not")
        print("Program not yet coded")
    elif(ch==13):
        print("Program to Find Greatest among three Numbers")
        a=input("Enter three Numeric Values:")
        b=input();c=input()
        if(a>b):
            if(a>c):
                print("Greatest="+str(a))
            else:
                print("Greatest="+str(c))
        else:
            if(b>c):
                print("Greatest="+str(b))
            else:
                print("Greatest="+str(c))
    elif(ch==14):
        print("Program to Find the given Number is prime or not")
        p=input("Enter a Numberic value:")
        count=0
        for i in range(1,p+1):
            if(p%i==0):
                count=count+1
        if(count==2):
            print("The given Number is a Prime")
        else:
            print("The given Number is not a Prime")
        count=0
    elif(ch==15):
        print("Program to Print Prime Numbers Present in an Interval")
        interv=input("Enter the Range to Print Prime Numbers:")
        p=2
        count=0
        while(p<=interv):
            for i in range(1,p+1):
                if(p%i==0):
                    count=count+1
            if(count==2):
                print(str(p))
            count=0
            p=p+1
    elif(ch==16):
        print("Program to Find a Factorial of a Number")
        fac=input("Enter a Numeric a Value:")
        x=1
        while(fac>0):
            x=x*fac
            fac=fac-1
        print("Factorial="+str(x))
    elif(ch==17):
        print("Program to Print Multiplication Table")
        t=input("Enter Numeric Value:")
        for i in range (1,11):
            r=t*i
            print(str(t)+"X"+str(i)+"="+str(r))
    elif(ch==18):
        print("Program to Print Fibonacci Series")
        a=1;b=1;r=0
        fib=input("Enter Range to Print Fibonacci Series:")
        print(str(a))
        print(str(b))
        while(r<=fib):
            r=a+b
            print(r)
            a=b;b=r
    elif(ch==19):
        print("Program to Find Given Number is Armstrong or NOT")
        ar=input("Enter a Numeric Value:")
        x=ar;count=0;r=0;s=ar
        while(s>0):
            s=s/10
            count=count+1
        while(x>0):
            t=x%10
            r=r+(t**count)
            x=x/10
        if(r==ar):
            print("Amstrong")
        else:
            print("Not Amstrong")
    elif(ch==20):
        print("Program to print Armstrong Numbers in Range")
        ran=input("Enter the Range to print Armstrong Numbers:")
        x=1
        while(x<ran):
            count=0;ar=x;r=0
            while(x>0):
                x=x/10
                count=count+1
                print(count)
            x=ar
            while(x>0):
                t=x%10
                r=r+(t**count)
                x=x/10
            if(r==ar):
                print(r)
            x=x+1
    else:
        print("Given Input is Not Available.")


