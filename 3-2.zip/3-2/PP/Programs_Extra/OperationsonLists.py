import functools
n=input("Enter Number of Elements in List:")
l=[]
l1=[]
def evenorodd(ev):
    if(ev%2==0):
        return 1
def add2(ev):
    ev=ev+2
    return ev
def add(x,y):
    return x+y
print("Enter the Elements:-")
for i in range(0,n):
    x=input()
    l.append(x)
while(1):
    x=input("Enter the 0 to Stop or 1-18 for a list operation:")
    if(x==0):
        print("Final List is "+str(l))
        break
    if(x==1):
        e=input("Enter the Element to Append:")
        l.append(e)
        print l
    elif(x==2):
        e=input("Enter the Element to Insert:")
        ind=input("Enter Element Index:")
        l.insert(ind,e)
        print l
    elif(x==3):
        ind=input("Enter the Element index to Pop:")
        l.pop(ind)
        print l
    elif(x==4):
        ind=input("Enter Element Index to Delete:")
        del l[ind]
        print l
    elif(x==5):
        e=input("Enter the Element to get Index Location:")
        ind=l.index(e)
        print("Index is "+str(ind))
    elif(x==6):
        print("Elements are sorted:")
        l.sort()
        print l
    elif(x==7):
        e=input("Enter the Element to Remove")
        l.remove(e)
        print(l)
    elif(x==8):
        print("Elements are in Reverse Order:")
        l.reverse()
        print l
    elif(x==9):
        n1=input("Enter number of Elements in Second List:")
        print("Enter the Elements:-")
        for j in range(0,n1):
            y=input()
            l1.append(y)
        l.extend(l1)
        print("Extended List is ")
        print(l)
    elif(x==10):
        print("To print Values and Index using enumerate:-")
        for j,ind in enumerate(l):
            print(j,ind)
    elif(x==11):
        print("To print Length using Range:-")
        c=0
        for j in range(len(l)):
            c=c+1
        print(c)
    elif(x==12):
        print("Even Elements in List:-")
        evens=list(filter(evenorodd,l))
        print evens
    elif(x==13):
        print("Use of Map in List:-")
        doublenum=list(map(add2,l))
        print doublenum
    elif(x==14):
        n1=input("Enter number of Elements in Second List:")
        print("Enter the Elements:-")
        for j in range(0,n1):
            y=input()
            l1.append(y)
        ind=input("Enter index to Insert the List:")
        l.insert(ind,l1)
    elif(x==15):
        print("Implementing reduce on List:-")
        v=functools.reduce(add,l)
        print v
    elif(x==16):
        print("Cloning Lists:-")
        l2=[]
        l2=l
        print(l2)
    elif(x==17):
        print("doubling a list:-")
        l=l*2
        print(l)
    elif(x==18):
        print("Adding Elements of Two Lists:-")
        n1=input("Enter Number of Elements of Second List:")
        print("Enter the Elements:-")
        for j in range(0,n1):
            a=input()
            l1.append(a)
        if(len(l)>len(l1)):
            r=len(l1)
        else:
            r=len(l)
        for i in range(r):
            l[i]=l[i]+l1[i]
        print(l)
    else:
        print("NOT AVAILABLE")
