def nearly_equal(a,b):
    if(len(a)!=len(b) and len(a)!=len(b)-1):
        print("Strings are Not Equal.")
        return
    al=a;l=[];count=0;x=0
    print("Given strings are "+a+","+b)
    a=a.lower()
    b=b.lower()
    for i in range(len(al)):
        if(a[i]==b[i]):
            l.append(a[i])
        elif(a[i]!=b[i]):
            if(a[i]==b[i+1] and count<=1):
                l.append(a[i])
            else:
                x=x+1
                break
            if(count<=1):
                count=count+1
        else:
            l.append(b[i])
            break       
    string=("").join(l)
    print(string)
    if(x==0):
        print("Both strings are Nearly Equal with Single Mutation.")
    else:
        print("Strings are not Equal.")
                
x=str(input("Enter a String:"))
y=str(input("Enter Another String:"))
nearly_equal(x,y)
