def unique(l):
    print l
    t=[]
    d=dict()
    for i in l:
        x=str(i)
        if x in d.keys():
            d[x]=d[x]+1
        else:
            d[x]=1
    #print d
    for i in d.keys():
        if(d[i]==1):
            t.append(i)
    print t

l=[1,2,3,4,5,6,7,1,2,3,4,5]
unique(l)
