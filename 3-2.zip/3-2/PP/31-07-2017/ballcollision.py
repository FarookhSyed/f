x1=input("Enter the x,y Cordinates of Ball1:")
y1=input()
r1=input("Enter the Radii of Ball1:")
x2=input("Enter the x,y Cordinates of Ball2:")
y2=input()
r2=input("Enter the Radii of Ball2:")
ball1=(x1,y1,r1)
ball2=(x2,y2,r2)
def ball_collide(ball1,ball2):
	x=(ball2[0]-ball1[0])**2
	y=(ball2[1]-ball1[1])**2
	z=(x+y)**0.5
	if(z<=(ball1[2]+ball2[2])):
		print("Distance between two Balls = "+str(z))
		print("Sum of radii = "+str(ball1[2]+ball2[2]))
		return 1
	return 0
if(ball_collide(ball1,ball2)):
	print("The Balls Collide with Each Other.")
else:
	print("The Balls Does not Collide with each Other.")
