n=input("Enter Length of List:")
l=[];d=dict()
for i in range(n):
	x=input("Enter the Element:")
	l.append(x)
x=0;y=0
for i in l:
	x=x+i
	if i in d.keys():
		d[i]=d[i]+1
	else:
		d[i]=1
mean=x/(n*1.0)
x=0
mode=[]
for i in d.keys():
	if(d[i]>y):
		y=d[i]
for i in d.keys():
        if (y==d[i]):
                mode.append(i)
l1=l
l1.sort()
if(len(l1)%2!=0):
	x=(len(l1)/2)
print l1
median=l1[x]
if(len(l1)%2==0):
	y=x=(len(l1)/2)
	y=l1[y]
	x=l1[x-1]
	median=(x+y)/2
print("Mean of List = "+str(mean))
print("Median of List = "+str(median))
print("Mode of List = "+str(mode))
		
	
