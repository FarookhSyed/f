r=input("Enter Range to display Prime Numbers:")
count=0
a=2
while a<=r:
    for x in range(1,a+1):
        if(a%x==0):
            count = count+1
    if count==2:
        print(str(a)+" is a Prime Number")
    count=0
    a=a+1
