
a=input("Enter Integer Value:")

while a>=0:
    print(a)
    a=a-1
