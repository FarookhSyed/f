
for x in range(2,11):
    print "For 1/"+str(x)+" Decimal Number = "+str(float(1.0/x))
