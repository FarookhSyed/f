
a=input("Enter a Integer value:")

if (a%2==0):
    print("Given Number is Even.")
else:
    print("Given Number is Odd.")
