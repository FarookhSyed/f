import string
file=open("sample.txt")
data=file.read()
lines=data.split("\n")
words=string.split(data)
characters=[]
for i in data:
    #if(i!="\n"):
        characters.append(i)
print("Number of Lines = "+str(len(lines)))
print("Number of Words = "+str(len(words)))
print("Number of Characters = "+str(len(characters)))
