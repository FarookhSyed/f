file=open("sample.txt")
data=file.read()
lines=data.split("\n")
characters=0
newdata=[]
for l in lines:
    x=-1;i=0
    while(i<len(l)):
        newdata.append(l[x])
        x=x-1
        i=i+1
    newdata.append("\n")
newfile = " ".join(newdata)
print newfile
    
    
