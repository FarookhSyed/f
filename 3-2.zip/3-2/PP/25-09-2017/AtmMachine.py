class ATMMachine:
    MachineCount=0
    accnos=dict()
    def __init__(self,name):
        ATMMachine.MachineCount+=1
        self.machineId=name
        print("Machine "+str(self.machineId)+" is ready for Transactions.")
        self.amount=0
    def __del__(self):
        print("Due to Some Techinal problems Destroying Machine "+str(self.machineId))
        ATMMachine.MachineCount-=1
    def MoneyIN(self,amount,accno):
        if(accno not in ATMMachine.accnos.keys()):
            ATMMachine.accnos[accno]=amount
        else:
            ATMMachine.accnos[accno]+=amount
        self.amount+=amount
        print(str(amount)+" added to Machine by Account "+str(accno))
    def MoneyOUT(self,amount,accno):
        if(accni not in keys(ATMMachine.accnos)):
            print("No Account found")
        else:
            ATMMachine.accnos[accno]-=amount
        self.amount-=amount
        print(str(amount)+" removed from Machine by Account "+str(accno))
atm1=ATMMachine("atm1")
atm2=ATMMachine("atm2")
atm3=ATMMachine("atm3")
atm4=ATMMachine("atm4")
atm5=ATMMachine("atm5")
atm6=ATMMachine("atm6")
#Money Transfers in ATM
atm1.MoneyIN(3000,"kishore")
atm2.MoneyIN(5000,"Hari")

del atm1

        
