class Robot:
    population=0
    def __init__(self,name):
        self.name=name
        print("Initializing {0}...".format(self.name))
        Robot.population+=1
    def __del__(self):
        print("{0} is being Destroyed!".format(self.name))
        Robot.population-=1
        if Robot.population==0:
            print("{0} was last one.".format(self.name))
        else:
            print("There are still {0:d} robot(s) working.".format(Robot.population))
    def sayHi(self):
        print("Greetings Master call me {0}.".format(self.name))
    def howMany():
        print("We have {0:d} robot(s).".format(Robot.population))
    howMany=staticmethod(howMany)
droid1=Robot('robo1')
droid1.sayHi()
Robot.howMany()
droid2=Robot('robo2')
droid2.sayHi()
Robot.howMany()
print("Robots can do some work here.")
print("Now destroying robots")
del droid1
del droid2
Robot.howMany()
        
