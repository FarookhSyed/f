#include<iostream>
using namespace std;
#include<string.h>
#include<stdlib.h>

struct Tree;

struct Node{
    char c;
    int count;
    int internal;
    Tree *loc;
};

struct Tree{
    Node left,right;
    int count;
};

Node *freq;
Tree *tre;
int freql=0,root,cdl=0;
string code="00001111110101101010";
string s="";

void haffmanTreeGen();

int decoder();

int main(){
    //cout<<"Enter Encoded Value(only 0,1):";
    //cin>>code;
    cdl = code.length();
    freql = 4;
    //cout<<"Enter number of Chars:";
    //cin>>freql;
    freq = new Node[freql];
    //cout<<"Enter the Char Count (format:char count):";
    char c[]={'a','b','c','d'};
    int count[]={3,3,2,3};
    for(int i=0;i<freql;i++){
        //cout<<i<<" ";
        //cin>>c;
        //cin>>count;
        freq[i].c = c[i];
        freq[i].count = count[i];
        freq[i].internal = 0;
        freq[i].loc = NULL;
        //cout<<freq[i].count<<endl;
    }
    haffmanTreeGen();
    //int x = decoder();
    //if(x==0)return 0;
    //cout<<s;
    return 0;
}

void haffmanTreeGen(){
    Node *temp1 = new Node[freql];
    for(int i=0;i<freql;i++)temp1[i]=freq[i];
    int fl=freql;
    for(int n=0;n<fl;n++){
        int least[2];
        cout<<'c';
        for(int i=0;i<fl;i++){
            cout<<'c';
            if(i==0){
                least[0]=i;break;cout<<'c';
            }
            else if(i==1){
                if(temp1[0].count<temp1[1].count){
                    least[1]=i;
                }
                else{
                    least[0]=i;
                    least[1]=i-1;
                }cout<<'c';break;
            }
            else{
                if(temp1[least[1]].count>temp1[i].count){
                    if(temp1[least[0]].count>temp1[i].count){
                        least[1]=least[0];
                        least[0]=i;
                    }
                    else least[1]=i;
                }cout<<'c';
            }
            cout<<least[0]<<" "<<least[1]<<endl;
        }
        Node x;
        x.count = temp1[least[0]].count+temp1[least[1]].count;
        cout<<x.count;
        x.internal = 1;
        tre[n].left = temp1[least[0]];
        tre[n].right = temp1[least[1]];
        tre[n].count = x.count;
        x.loc = &tre[n];
        if(least[1]==fl-1)temp1[least[0]] = x;
        else if(least[0]==fl-1)temp1[least[1]] = x;
        else{
            temp1[least[0]] = x;
            temp1[least[1]] = temp1[fl-1];
        }
        fl--;
        root++;
    }

}

int decoder(){
    Tree t = tre[root-1];
    int i=0;
    while(i<cdl){
        if(code[i] == 0){
            if(t.left.loc){
                continue;
            }
            else if(t.left.internal){
                s = s+t.left.c;
                cout<<s;
                t = tre[root-1];

            }
            else{
                cout<<"DECODING NOT POSIIBLE.\n";
                return 0;
            }
        }
        else if(code[i]==1){
            if(t.right.loc){
               continue;
            }
            else if(t.right.internal){
                s = s+t.right.c;
                cout<<s;
                t = tre[root-1];
            }
            else{
                cout<<"DECODING NOT POSIIBLE.\n";
                return 0;;
            }
        }
        else{
                cout<<"DECODING NOT POSIIBLE.\n";
                return 0;
        }
        i++;
    }
    return 1;
}
