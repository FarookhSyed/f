#include<iostream.h>
int a[] = {6,3,18,45,23,14,96,13,47,54,387,10},b[20],c[20],d[20],*mem;
int k=2,m=3,n=12,seg;
int r=0,s=0;
int p,q;
int t=1;

void mergerun();
void sort(int arr[],int n){
	for(int i=0;i<n;i++)
		for(int j=i+1;j<n;j++)
			if(arr[i]>arr[j]){
				int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
			}
}
void sortrun();

int main(){
	mem = new int[m];
	sortrun();
	mergerun();
	return 0;
}

void mergerun(){
	while(seg>1){
   	int p=0,q=0;
		int x = 0, y = 0;
		//if(seg%2!=0)seg+=1;
		seg = seg/2;
		cout<<seg<<endl;
		if(t==1){
			t=0;
			for(int i=0;i<seg/2;i++){
				while(x<m && y<m){
					if(c[x]<d[y]){
						a[p] = c[x];cout<<a[p]<<" ";
						p++;x++;
					}
					else{
						a[p] = d[y];cout<<a[p]<<" ";
						p++;y++;
					}
				}
				while(x<m){
					a[p] = c[x];cout<<a[p]<<" ";
					p++;x++;
				}
				while(y<m){
					a[p] = d[y];cout<<a[p]<<" ";
					p++;y++;
				}
				cout<<endl;
				m = m*2;
				while(x<m && y<m){
					if(c[x]<d[y]){
						b[q] = c[x];cout<<b[q]<<" ";
						q++;x++;
					}
					else{
						b[q] = d[y];cout<<b[q]<<" ";
						q++;y++;
					}
				}
				while(x<m){
					b[q] = c[x];cout<<b[q]<<" ";
					q++;x++;
				}
				while(y<m){
					b[q] = d[y];cout<<b[q]<<" ";
					q++;y++;
				}
			}
			cout<<endl;
		}
		else{
			t=1;
			for(int i=0;i<seg;i++){
				while(x<m && y<m){
					if(a[x]<b[y]){
						c[p] = a[x];cout<<c[p]<<" ";
						p++;x++;
					}
					else{
						c[p] = b[y];cout<<c[p]<<" ";
						p++;y++;
					}
				}
				while(x<m){
					c[p] = a[x];cout<<c[p]<<" ";
					p++;x++;
				}
				while(y<m){
					c[p] = b[y];cout<<c[p]<<" ";
					p++;y++;
				}
				cout<<endl;
				m = m*2;
				while(x<m && y<m){
					if(a[x]<b[y]){
						d[q] = a[x];cout<<d[q]<<" ";
						q++;x++;
					}
					else{
						d[q] = b[y];cout<<d[q]<<" ";
						q++;y++;
					}
				}
				while(x<m){
					d[q] = a[x];cout<<d[q]<<" ";
					q++;x++;
				}
				while(y<m){
					d[q] = b[y];cout<<d[q]<<" ";
					q++;y++;
				}
			}
         cout<<endl;
		}
	}
}

void sortrun(){
	seg = (n/m);
	cout<<seg<<endl;
	int j,k;
	for(int i=0;i<seg/2;i++){
		int x = i*m*2;
		int l=0;
		for(j=x;j<x+m;j++){
			 mem[l]=a[j];
			 l++;
		}
		sort(mem,l);
		for(j=0;j<l;j++){
			 c[r]=mem[j];cout<<c[r]<<" ";
			 r++;
		}
		cout<<endl;
		l=0;
		for(k=x+m;k<x+m+m;k++){
			 mem[l]=a[k];cout<<a[k]<<" ";
			 l++;
		}
		sort(mem,l);
		for(j=0;j<l;j++){
			 d[s]=mem[j];//cout<<mem[j]<<" ";
			 s++;
		}
		cout<<endl;
	}
}