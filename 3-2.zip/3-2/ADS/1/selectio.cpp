#include<iostream.h>
int *a,n;
void selectionsort(){
	int i,j;
	for(i=0;i<n;i++){
		for(j=1;j<n;j++){
			if(a[i]>a[j]){
				int temp=a[j];
				a[j]=a[i];
				a[i]=temp;
			}
		}
	}
	cout<<"Elements are ";
	for(i=0;i<n;i++){
   	cout<<a[i]<<" ";
	}
}
int main(){
	cout<<"Enter Size of the Elements:";
	cin>>n;
	a=new int[n];
	cout<<"Enter the Elements:-\n";
	int i;
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	selectionsort();
	return 0;
}
