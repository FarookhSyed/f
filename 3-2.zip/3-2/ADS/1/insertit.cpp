#include<iostream.h>
int *a,n;
void insert(int i){
	int j=i;
	while(j>0){
		if(a[j]<a[j-1]){
			int temp=a[j];
			a[j]=a[j-1];
			a[j-1]=temp;
		}
		j--;
	}
   for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
   cout<<endl;
}
void insertitionsort(){
	int i;
	for(i=1;i<n;i++){
		insert(i);
	}
   cout<<"Elements are \n";
	for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
}
int main(){
	cout<<"Enter the Size of the Elements:";
	cin>>n;
	a=new int[n];
	int i;
   cout<<"Enter the Elements:-\n";
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	insertitionsort();
	return 0;
}