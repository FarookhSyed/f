#include<iostream.h>
int *a,n;
void merge(int low,int high){
	int i=low-1,j=high;
	while(i<j){
		if(a[i]>a[i+1]){
			int temp=a[i];
			a[i]=a[i+1];
			a[i+1]=temp;
		}
      i++;
	}
   for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
   cout<<endl;
}
void mergesort(int low,int high){
	int avg;
	avg=(low+high)/2;
	if(low<avg){
		mergesort(low,avg);
		mergesort(avg+1,high);
	}
   merge(low,high);
}
 int main(){
	cout<<"Enter the Size of the Elements:";
	cin>>n;
	a=new int[n];
	int i;
	cout<<"Enter the Elements:-\n";
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	mergesort(1,n);
	cout<<"Elements are \n";
	for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
	return 0;
}