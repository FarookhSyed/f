#include<iostream.h>
int *a,n;
void bubblesort(){
	int i,j;
	for(i=0;i<n;i++){
		for(j=i;j<n-i-1;j++){
			if(a[j-1]>a[j]){
				int temp=a[j-1];
				a[j-1]=a[j];
            a[j]=temp;
			}
		}
	}
	cout<<"Elements are \n";
   for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
}
int main(){
	cout<<"Enter the Size of the Elements:";
	cin>>n;
	a=new int[n];
	cout<<"Enter the Elements:-\n";
	int i;
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	bubblesort();
	return 0;
}