#include<iostream>
using namespace std;
#include<limits.h>

class BinaryHeap{
	struct Node{
		struct Node *left,*right,*root;
		int pos;
		int data;
	};
	struct Array{
		struct Array *next;
		struct Node *node;
	};
	struct Node *head,*tail;
	struct Array *root,*end;
	int heap,pos;
	Node *createNode(){
		struct Node *n = new struct Node;
		n->left = NULL;
		n->right = NULL;
		n->root = NULL;
		n->data = 0;
		return n;
	}
	void insert(int data,struct Array *t){
		if(pos==1){
			head->data = data;
		}
		else{
			struct Node *n = createNode();
			n->data = data;
			t->node = n;
			struct Array *a = root;
			for(int i=1;i<pos/2;i++)a = a->next;
			//cout<<a->node->data<<" "<<pos<<" \n";
			t->node->root = a->node;
			if(a->node->left==NULL){
				a->node->left = t->node;
				tail = a->node->left;
			}
			else{
				a->node->right = t->node;
				tail = a->node->right;
			}
			heapifyInsert(t->node);
		}
		pos++;
	}
	int heapifyInsert(struct Node *n){
		if(head==n)return 1;
		if(heap==1){
			if((n->data)<=(n->root->data))return 1;
			else{
				int x = n->data;
				n->data = n->root->data;
				n->root->data = x;
				n = n->root;
				heapifyInsert(n);
			}
		}
		else{
			if((n->data)>=(n->root->data))return 1;
			else{
				int x = n->data;
				n->data = n->root->data;
				n->root->data = x;
				n = n->root;
				heapifyInsert(n);
			}
		}
	}
	int heapifyDelete(){
		struct Node *t = head;
		while(t->left!=NULL || t->right!=NULL){
			struct Node *a;
			if(heap==1){
				if(t->left->data > t->data){
					int d = t->data;
					t->data = t->left->data;
					t->left->data = d;
					a = t->left;
				}
				if(t->right!=NULL){
					if(t->right->data > t->data){
						int d = t->data;
						t->data = t->right->data;
						t->right->data = d;
						if(t->left->data<t->right->data)a=t->right;
					}
				}
				t = a;
			}
			if(heap==2){

				if((t->left->data) < (t->data)){
					int d = t->data;
					t->data = t->left->data;
					t->left->data = d;
					a = t->left;
				}
				if(t->right!=NULL){
					if((t->right->data) < (t->data)){
						int d = t->data;
						t->data = t->right->data;
						t->right->data = d;
						if(t->left->data>t->right->data)a=t->right;
					}
				}
				t = a;
			}
			//cout<<t->data<<" ";
		}
	}
	void inorder(struct Node *temp){
		if(temp->left!=NULL)inorder(temp->left);
		cout<<temp->data<<" ";
		if(temp->right!=NULL)inorder(temp->right);
	}
	void preorder(struct Node *temp){
		cout<<temp->data<<" ";
		if(temp->left!=NULL)preorder(temp->left);
		if(temp->right!=NULL)preorder(temp->right);
	}
	void postorder(struct Node *temp){
		if(temp->left!=NULL)postorder(temp->left);
		if(temp->right!=NULL)postorder(temp->right);
		cout<<temp->data<<" ";
	}
	void leveloforder(struct Array *temp){
		cout<<temp->node->data<<" ";
		if(temp->next->next!=NULL)leveloforder(temp->next);
	}
	public:
		BinaryHeap(){
			pos=1;
			root = new struct Array;
			head = createNode();
			root->node = head;
			root->next = NULL;
			cout<<"\n\t1.Max-Heap\n\t2.Min-Heap\nEnter Option:";
			int a=2;
			cin>>a;
			if(a==2)heap = 2;
			else heap = 1;
		}
		void insert(int a[],int n){
			struct Array *t = root;
			for(int i=0;i<n;i++){
				insert(a[i],t);
				t->next = new struct Array;
				t=t->next;
				end = t;
			}
			//cout<<pos<<endl;
		}
		void insert(int data){
			insert(data,end);
			end->next = new struct Array;
			end = end->next;
			//cout<<"tail"<<tail->data;
		}
		void del(){
			struct Node *t = head,*t1 = tail;
			struct Array *n = root,*n1;
			//inorder(t);cout<<endl;
			//cout<<pos<<endl;
			pos--;
			for(int i=1;i<pos-1;i++)n=n->next;
			//cout<<n->node->data;
			tail = n->node;
			t->data = t1->data;
			if(t1->root->left->data==t1->data)t1->root->left=NULL;
			else t1->root->right=NULL;
			delete n->next;
			end = n->next = new struct Array;
			heapifyDelete();
			//inorder(t);
		}
		void print(){
			struct Node *t = head;
			sw:cout<<"\n\t1.Inorder\n\t2.Postorder\n\t3.Preorder\n\t4.Level of Order\nEnter the Choice:";
			int c;
			cin>>c;
			switch(c){
				case 1:
					inorder(t);
					break;
				case 2:
					postorder(t);
					break;
				case 3:
					preorder(t);
					break;
				case 4:
					leveloforder(root);
					break;
				default:
					cout<<"wrong choice.";
					goto sw;
			}
		}
};


int main(){
	BinaryHeap b;
	cout<<"Enter the Size of ARRAY:";int n;
	cin>>n;
	cout<<"Enter the Elements:-\n";
	int *a = new int[n];
	for(int i=0;i<n;i++)cin>>a[i];
	b.insert(a,n);
	while(1){
		cout<<"\n\t1.Display\n\t2.Insert\n\t3.Delete\n\t4.EXIT\nEnter your Choice:";
		int i;cin>>i;
		switch(i){
			case 1:
				b.print();
				break;
			case 2:
				cout<<"Enter Data to insert:";int d;cin>>d;
				b.insert(d);
				break;
			case 3:
				b.del();
				break;
			default:
				cout<<"EXITING...";
				goto exit;
		}
	}
	exit:return 0;
}
