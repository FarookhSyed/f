#include<iostream.h>

int compare(dict[],char);

struct dict{
	char c;
	int count;
	int tcount;
};

class HuffmanEncoder{
	public:
		HuffmanEncoder(){
			 str = "aaaabbbccdddddf";
		}
	private:
		char *str;
		dict *freq;
}

int main(){


	return 0;
}

int compare(dict d[],char c){
	for(int i=0;i<d[0].tcount)
}