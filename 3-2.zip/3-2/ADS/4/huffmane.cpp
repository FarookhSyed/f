#include<iostream.h>
#include<math.h>
struct code{
	char *x;
};
struct dict{
	char c;
	int count;
	int inter;
};

char *str = "aaaabbbccdddddf" ;
dict freq[5];
int hufftree[] = {1,3,2,6,3,15,9,4,5};
struct code *codes;
int len=0;

void sorter(dict[],dict[]);

void assign();
void codegen(int);
void huffmanTree(char*,dict[],int);


int main(){
	codes = new code[5];
	assign();
	cout<<"String is "<<str<<endl;
	cout<<"Frequency of char is :";

	for(int i=0;i<5;i++){
		cout<<freq[i].count<<" ";
		len+=freq[i].count;
	}
	cout<<endl<<"Encoded Code:";

	for(i=0;i<len;i++){
		 switch(str[i]){
			case 'a':
				cout<<codes[0].x;
				break;
			case 'b':
				cout<<codes[1].x;
				break;
			case 'c':
				cout<<codes[2].x;
				break;
			case 'd':
				cout<<codes[3].x;
				break;
			case 'f':
				cout<<codes[4].x;
				break;
		 }
	}
	cout<<endl;
	huffmanTree(str,freq,len);
	//codegen(8);
	return 0;
}
void assign(){
	freq[0].c = 'a';
	freq[1].c = 'b';
	freq[2].c = 'c';
	freq[3].c = 'd';
	freq[4].c = 'f';

	freq[0].count = 4;
	freq[1].count = 3;
	freq[2].count = 2;
	freq[3].count = 5;
	freq[4].count = 1;

	codes[0].x = "10";
	codes[1].x = "01";
	codes[2].x = "001";
	codes[3].x = "11";
	codes[4].x = "000";
}

void codegen(int ele){
	int level=0;
	int n = 0;
	int el=0;

	while(el<=ele){
		el = el+ pow(2,n);
      cout<<n<<" ";
		n++;
	}

	level = n;

	int root = 0;

}

void huffmanTree(char *str,dict freq[],int len){
	int tree[];
	for(int i=0;i<4;i++){
		dict *least = new dict[2];
		sorter(freq,least);
		int sum = least[0].count+least[1].count;

	}

}

void sorter(dict freq[],dict least[]){
	dict x = freq[0];
	for(int i=1;i<5;i++){
		if(freq[i].count<x.count){
			x = freq[i];
		}
	}
	least[0] = x;
	x = freq[0];
	for(i=1;i<5;i++){
		if(freq[i].count<x.count && freq[i].c != least[0].c){
			x = freq[i];
		}
	}
	least[1] = x;

	cout<<least[0].c<<" "<<least[1].c<<endl;;
}
