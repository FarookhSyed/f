#include<iostream>
using namespace std;
#include<string>
struct Tree;

struct Node{
	char c;
	int count;
	int internal;
	Tree *loc;
};

struct Tree{
	Node left;
	Node right;
	int count;
};

struct encodedvalue{
	char c;
	std::string s;
};

std::string str;

int *codes,strl,freql=1;
Tree *tre;
Node *freq;
encodedvalue *val;
int root;
std::string s="";

void cod(Tree *node);
void huffmanTreeGen();
void codeGen();
void intialise();

int main(){

	cout<<"Enter a String:";
	std::cin>>str;

	strl = str.length();

	intialise();

	huffmanTreeGen();

	codeGen();
	std::string code="";
	cout<<endl<<"Encoded Value is ";
	for(int i=0;i<strl;i++){
		int j=0;
		while(str[i]!=val[j].c)j++;
		code = code+val[j].s;
	}
	std::cout<<code;
	return 0;
}

void intialise(){
	Node *temp = new Node[strl];
	for(int i=0;i<strl;i++){
		//cout<<str[i]<<" ";
		for(int j=0;j<freql;j++){
			if(temp[j].c == str[i]){
				temp[j].count++;
				break;
			}
			else if(j == freql-1 || freql == 0){

				temp[freql-1].c = str[i];
				//cout<<temp[freql].c<<str[i]<<" ";
				temp[freql-1].internal = 0;
				temp[freql-1].count = 1;
				freql++;
				break;
			}
		}
	}
	freql--;//Setting back freq value
	freq = new Node[freql];
	val = new encodedvalue[freql];
	for(int i=0;i<freql;i++){
		freq[i] = temp[i];
		//cout<<freq[i].c<<freq[i].count<<" ";
		val[i].c = freq[i].c;
	}
}

void huffmanTreeGen(){
	Node *temp1 ,temp2;
	temp1 = new Node[freql];
	for(int i=0;i<freql;i++)
		temp1[i] = freq[i];
	int fl = freql;
	tre = new Tree[freql];
	//cout<<endl;
	while(fl>1){
		int least[2];
		//for(int i=0;i<fl;i++){
			//cout<<temp1[i].count<<" ";
		//}cout<<endl;
		for(int i=0;i<fl;i++){
			if(i==0){
				least[0]=i;
			}
			if(i==1){
				if(temp1[i].count<temp1[0].count){
					least[0] = i;
					least[i] = 0;
				}
				else
					least[1]=1;
			}
			else{
				if(temp1[i].count<temp1[least[1]].count){
					if(temp1[i].count<temp1[least[0]].count){
						least[1]=least[0];
						least[0]=i;
					}
					else
						least[1]=i;
				}
			}
			if(temp1[least[0]].count==temp1[least[1]].count){
				if(temp1[least[1]].internal && !temp1[least[0]].internal){
					int l = least[0];
					least[0] = least[1];
					least[1] = l;
				}
			}
		}
		Node x;
		x.internal=1;
		x.count = temp1[least[0]].count+temp1[least[1]].count;
		//cout<<temp1[least[0]].count<<" "<<temp1[least[1]].count<<endl;
		tre[freql-fl].left = temp1[least[0]];
		tre[freql-fl].right = temp1[least[1]];
		tre[freql-fl].count = x.count;
		x.loc = &tre[freql-fl];
		if(least[0]!=fl-1 && least[1]!=fl-1){
			temp1[least[0]] = temp1[fl-1];
			temp1[least[1]] = x;
			temp1[fl-1] = temp2;
		}
		else{
			if(least[0]!=fl-1){
				temp1[least[0]] = x;
				temp1[least[1]] = temp2;
			}
			else if(least[1]!=fl-1){
				temp1[least[1]] = x;
				temp1[least[0]] = temp2;
			}
		}
		root = freql-fl;
		fl--;
	}
	//for(int i=0;i<fl;i++){
		//cout<<temp1[i].count<<" ";
	//}
	//cout<<endl;
}


void codeGen(){
	s = "0";
	cod(tre[root].left.loc);
	s= "1";
	cod(tre[root].right.loc);
}

void cod(Tree *node){
	if(node->left.loc){
		//cout<<node->count<<" ";
		s = s+"0";
		cod(node->left.loc);
	}
	else{
		s = s+"0";
		//cout<<node->left.c<<" ";
		int i=0;
		while(node->left.c!=val[i].c)i++;
		val[i].s = s;
		//cout<<val[i].c<<val[i].s<<" ";
		s = s.substr(0, s.size()-1);
	}

	if(node->right.loc){
		//cout<<node->count<<" ";
		s = s+"1";
		cod(node->right.loc);
	}
	else{
		s = s+"1";
		//cout<<node->right.c<<" ";
		int i=0;
		while(node->right.c!=val[i].c)i++;
		val[i].s = s;
		//cout<<val[i].c<<val[i].s<<" ";
		s = s.substr(0, s.size()-1);
	}

	s = s.substr(0, s.size()-1);

}
