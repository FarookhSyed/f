#include<iostream>
using namespace std;

struct Bucket{
	int data;
	Bucket *next;
};
class HashTable{
	void createTable(){
		b = new Bucket[len];
		for(int i=0;i<len;i++){
			b[i].data = NULL;
			b[i].next = NULL;
		}
	}
	public:
		Bucket *b;
		int len;
		HashTable(){
			cout<<"Enter size of the hash table:";
			cin>>len;
			createTable();
		}
};

class OpenHasing{
	public:
		HashTable table;
		void insert(int data){
		    Bucket *temp;
			int mod = data%table.len;
			temp=&table.b[mod];
			cout<<"Modulo Value:"<<mod<<" ";
			if(temp->data==NULL)temp->data=data;
			else{
				Bucket *x = new Bucket;
				x->data=data;
				x->next=NULL;
				while(temp!=NULL)temp=temp->next;
				temp=x;
			}
			cout<<"-- Inserted Value:"<<temp->data<<endl;
		}
		void delet(int data){
			int mod = data%table.len;
			if(table.b[mod].data==data)table.b[mod]=*table.b[mod].next;
			else{
				Bucket *temp=&table.b[mod];
				while(temp->next->data!=data && temp->next!=NULL)temp=temp->next;
				if(temp->next->data==data){
					Bucket *x = temp->next;
					temp=x->next;
					x->next=NULL;
					delete x;
				}
			}
		}
		void print(){
			for(int i=0;i<table.len;i++){
				cout<<"Bucket Number:"<<i<<" "<<table.b[i].next<<"\n";
				Bucket *temp;
				//while(temp->next!=NULL){
					//temp=temp->next;
					//cout<<temp->data<<" ";
				//}
				cout<<endl;
			}
		}
};

int main(){
	OpenHasing A;
	for(int i=0;i<10;i++)
		A.insert(i*3+1);
		//A.insert(18);
	A.print();
	return 0;
}
