#include<iostream.h>
int n,*a;
void maxheap(int heap[],int in){
	int i=0,j=0;
	while(i<in){
		int x = a[i];
		heap[i] = x;
		for(j=i;j>0;j--){
			int y = j/2;
			if(j%2==0)y-=1;
			if(heap[j]>heap[y]){
				int temp = heap[j];
				heap[j] = heap[y];
				heap[y]  = temp;
			}else
				break;
		}
		i++;
	}
}
void heapsort(int in){
	int *heap = new int[in];
	maxheap(heap,in);
	for(int i=0;i<in;i++){
		a[i] = heap[i];
	}
	int temp = a[0];
	a[0] = a[in-1];
	a[in-1] = temp;
   cout<<"Elements:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }
    cout<<endl;
	if(in>1)
		heapsort(in-1);
}
void main(){
	 cout<<"Enter the Size of Elements:";
	 cin>>n;
	 a = new int[n];
	 cout<<"Enter the Elements:-\n";
	 for(int i=0;i<n;i++)
		cin>>a[i];
	 cout<<"Elements:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }
    cout<<endl;
	 heapsort(n);
	 cout<<"Elements after Sorting:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }

}

