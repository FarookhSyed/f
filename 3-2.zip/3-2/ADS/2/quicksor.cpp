#include<iostream.h>
int n,*a;
void quicksort(int n1,int n2){
	int p = n1;
	int i = n1+1;
	int j = n2;
	cout<<i<<" "<<j<<endl;
	int x,temp;
	for(x=0;x<=n2;x++){
		while(a[p]>a[i] && i<=n2){
			i=i+1;
			cout<<i<<"-";
		}
		while(a[p]<a[j] && j>=n1){
			j=j-1;
			cout<<j<<",";
		}
		if(i<j){
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
		if(i>j){
			break;
		}
	}
	if(i>j){
		temp = a[p];
		a[p] = a[j];
		a[j] = temp;
		if(n1<n2 && j>0 && j<n2){
			quicksort(n1,j-1);
			quicksort(j+1,n2);
		}
	}
	cout<<"Elements after Sort:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }
	 cout<<endl;
}
void main(){
	 cout<<"Enter the Size of Elements:";
	 cin>>n;
	 a = new int[n];
	 cout<<"Enter the Elements:-\n";
	 for(int i=0;i<n;i++)
		cin>>a[i];
	 cout<<"Elements:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }
    cout<<endl;
	 quicksort(0,n-1);
	 cout<<"Elements after Sorting:";
	 for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	 }

}

