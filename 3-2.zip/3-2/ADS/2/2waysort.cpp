#include <iostream.h>
#include <fstream.h>

void twoway(){

}
int main () {
	cout << "Place Elements in the BRIDGE.txt .\n";
	fstream BRIDGE;
	BRIDGE.open("BRIDGE.txt",ios::in);
	cout<<"Enter the Sperator used for the Elements:";
	char c;cin>>c;
	cout<<"Enter Size of Memory:";
	int m;cin>>m;
	//BRIDGE << 10;
	int a,b;
	int *ar = new int[m],count=0;
	while(BRIDGE >> a >> b && b==c){
		if(count&2==0 && count){
			sortrun(ar,count)
		}
		cout<<a;
		ar[count]= a;
		count++;
	}
	BRIDGE.close();
	return 0;
}
