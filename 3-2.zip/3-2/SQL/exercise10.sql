set serveroutput on;

DECLARE
 a integer := &FIRST_INTEGER;
 b integer := &SECOND_INTEGER;
 c integer;
 q float;

 
BEGIN
 c := a+b;
 dbms_output.put_line('SUM OF TWO INTEGERS IS '||c);
 c := a-b;
 dbms_output.put_line('DIFFERENCE BETWEEN TWO INTEGERS IS '||c);
 c := a*b;
 dbms_output.put_line('PRODUCT OF TWO INTEGERS IS '||c);
 q:=a/(b*1.0);
 dbms_output.put_line('DIVISION OF TWO INTEGERS IS '||q);

END;

set serveroutput on;

DECLARE
dept_name dept.dname%type;
emp_rec emp%rowtype;
emp_id emp.empno%type := &EMP_NUMBER;

BEGIN
select * into emp_rec from emp where empno = emp_id;
select dname into dept_name from dept where deptno = emp_rec.deptno;
dbms_output.put_line('Empolyee name is '||emp_rec.ename || ' payed salary of '||emp_rec.sal||' working at department '||dept_name);

END;


