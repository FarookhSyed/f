import java.io.*;
import java.util.Scanner;

class Rectangle{
	int l,b;
	public void area(){
		System.out.println("Area of Rectangle "+(l*b));
	}
}

class ClassMechanism{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Length and Breadth :");
		int a = in.nextInt();
		int b = in.nextInt();
		Rectangle r = new Rectangle();
		r.l = a;
		r.b = b;
		r.area();
	}
}