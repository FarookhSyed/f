import java.io.*;
import java.util.Scanner;

class Rectangle{
	public void area(){
		System.out.println("Area of Rectangle 0");
	}
	public void area(int a){
		System.out.println("Area of Rectangle "+(a*a));
	}
	public void area(int a,int b){
		System.out.println("Area of Rectangle "+(a*b));
	}
}

class MethodOverloading{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Length and Breadth :");
		int a = in.nextInt();
		int b = in.nextInt();
		Rectangle r1 = new Rectangle();
		System.out.println("l=0,b=0");
		r1.area();
		System.out.println("l="+a+",b="+a);
		r1.area(a);
		System.out.println("l="+b+",b="+b);
		r1.area(b);
		System.out.println("l="+a+",b="+b);
		r1.area(a,b);
	}
}