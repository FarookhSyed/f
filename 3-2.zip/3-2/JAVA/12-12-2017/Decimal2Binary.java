import java.io.*;
import java.util.Scanner;

class Decimal2Binary{
	static int bina;

	static void dec2Bin(int dec){
		int count=0,ob=0,x=1;
		while(dec>0){
			System.out.println(bina);
			x = dec%2;
			dec = dec/2;
			if(x==0){
				ob++;
			}
			else{
				for(int i=0;i<ob;i++)
					x*=10;
				ob=0;
				if(count==0){
					bina = x;
				}
				else{
					for(int i=0;i<count;i++)
						x*=10;
					bina=bina+x;
				}
				
			}
			//if(dec==0){
				
			//}
			count++;
		}
	}

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Decimal Number:");
		int dec = in.nextInt();
		dec2Bin(dec);
		System.out.println(bina);
	}
}