import java.io.*;
import java.util.Scanner;

class Rectangle{
	int l,b;
	Rectangle(int x,int y){
		l=x;
		b=y;
	}
	public void area(){
		System.out.println("Area of Rectangle "+(l*b));
	}
}

class Constructor{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Length and Breadth :");
		int a = in.nextInt();
		int b = in.nextInt();
		Rectangle r = new Rectangle(a,b);
		r.area();
	}
}