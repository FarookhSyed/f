import java.io.*;
import java.util.Scanner;

class Rectangle{
	int l,b;
	Rectangle(int x,int y){
		l=x;
		b=y;
	}
	Rectangle(int x){
		l=b=x;
	}
	Rectangle(){
		l=b=0;
	}
	public void area(){
		System.out.println("Area of Rectangle "+(l*b));
	}
}

class ConstructorOverloading{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Length and Breadth :");
		int a = in.nextInt();
		int b = in.nextInt();
		Rectangle r1 = new Rectangle();
		System.out.println("l=0,b=0");
		r1.area();
		Rectangle r2 = new Rectangle(a);
		System.out.println("l="+a+",b="+a);
		r2.area();
		Rectangle r3 = new Rectangle(b);
		System.out.println("l="+b+",b="+b);
		r3.area();
		Rectangle r4 = new Rectangle(a,b);
		System.out.println("l="+a+",b="+b);
		r4.area();
	}
}