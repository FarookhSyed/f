import java.io.*;
import java.util.*;

class ExceptionHandling{
	public static void main(String args[]){
		try{
			Scanner in = new Scanner(System.in);
			System.out.print("Enter two Numbers:");
			int a= in.nextInt();
			int b=in.nextInt();
			double c = a/b;
			System.out.println("Quotient = "+c);
		}
		catch(Exception e){
			System.out.println("Divide by Zero Exception.");
		}
	}
}