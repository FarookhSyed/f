import java.io.*;
import java.util.*;

class SuperClass{
	int i;
	SuperClass(int x){
		i = x;
	}
	public void display(){
		System.out.println("Value in Super Class:"+i);
	}
}

class SubClass extends SuperClass{
	int i;
	SubClass(int x,int y){
		super(x);
		i = y;
		System.out.println("Call Super method");
		super.display();			
	}
	
	public void display(){
		System.out.println("Call Sub method");
		System.out.println("Value in Super Class:"+super.i);
		System.out.println("Value in Sub Class:"+i);
	}
}

class SuperImplementation{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);

		System.out.print("Enter the Value for Super Class:");
		int x = in.nextInt();
		System.out.print("Enter the Value for Sub Class:");
		int y = in.nextInt();
		SubClass A = new SubClass(x,y);
		A.display();
	}
}