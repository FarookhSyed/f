import java.io.*;
import java.util.*;

interface Calculator{
	void add(int x,int y);
	void sub(int x,int y);
	void div(int x,int y);
	void multi(int x,int y);
}

class A implements Calculator{
	public void add(int x,int y){
		System.out.println("Addition of Numbers is "+(x+y));
	}
	public void sub(int x,int y){
		System.out.println("Difference of Numbers is "+(x-y));
	}
	public void div(int x,int y){
		System.out.println("Quotient of Numbers is "+(x/y));
	}
	public void multi(int x,int y){
		System.out.println("Product of Numbers is "+(x*y));
	}
}

class InterfacesImplementation{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		A ob = new A();
		System.out.print("Enter two Numbers:");
		int x = in.nextInt();
		int y = in.nextInt();
		ob.add(x,y);
		ob.sub(x,y);
		ob.div(x,y);
		ob.multi(x,y);
	
	}

}