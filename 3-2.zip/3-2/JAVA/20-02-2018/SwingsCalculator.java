import javax.swing.*;
import java.awt.event.*;


class SwingsCalculator implements ActionListener{

	JFrame f;
	JTextField t;
	JButton num[] = new JButton[10];
	JButton bdiv,bmul,bsub,badd,bclr,bdel,beq;

	double a,b,result;
	int operator;


	SwingsCalculator(){
		f = new JFrame("Calculator");
		t = new JTextField();

		for(int i=0;i<10;i++){
			num[i] = new JButton(""+i+"");
		}

		bdiv = new JButton("/");
		bmul = new JButton("*");
		bsub = new JButton("-");
		badd = new JButton("+");
		bclr = new JButton("C");
		bdel = new JButton("DELETE");
		beq = new JButton("=");

		t.setBounds(20,50,250,40);

		num[7].setBounds(20,200,50,40);
		num[8].setBounds(85,200,50,40);
		num[9].setBounds(155,200,50,40);
		bdiv.setBounds(220,200,50,40);
		
		num[4].setBounds(20,250,50,40);
		num[5].setBounds(85,250,50,40);
		num[6].setBounds(155,250,50,40);
		bmul.setBounds(220,250,50,40);

		num[1].setBounds(20,300,50,40);
		num[2].setBounds(85,300,50,40);
		num[3].setBounds(155,300,50,40);
		bsub.setBounds(220,300,50,40);

		num[0].setBounds(85,350,50,40);
		beq.setBounds(155,350,50,40);
		badd.setBounds(220,350,50,40);
		bclr.setBounds(20,350,50,40);


		bdel.setBounds(75,120,150,60);
		

		f.add(t);
		for(int i=0;i<10;i++){
			f.add(num[i]);
		}
		f.add(bdiv);
		f.add(bmul);
		f.add(bsub);
		f.add(badd);
		f.add(bclr);
		f.add(bdel);
		f.add(beq);

		f.setLayout(null);
		f.setVisible(true);
		f.setSize(300,500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setResizable(false);

		for(int i=0;i<10;i++){
			num[i].addActionListener(this);
		}
		bdiv.addActionListener(this);
		bmul.addActionListener(this);
		bsub.addActionListener(this);
		badd.addActionListener(this);
		bclr.addActionListener(this);
		bdel.addActionListener(this);
		beq.addActionListener(this);
			
	}

	public void actionPerformed(ActionEvent e){
		for(int i=0;i<10;i++)
			if(e.getSource()==num[i])
				t.setText(t.getText().concat(""+i+""));
		if(e.getSource()==badd){
            		a=Double.parseDouble(t.getText());
            		operator=1;
            		t.setText("");
       		 } 
        
        if(e.getSource()==bsub)
        {
            a=Double.parseDouble(t.getText());
            operator=2;
            t.setText("");
        }
        
        if(e.getSource()==bmul)
        {
            a=Double.parseDouble(t.getText());
            operator=3;
            t.setText("");
        }
        
        if(e.getSource()==bdiv)
        {
            a=Double.parseDouble(t.getText());
            operator=4;
            t.setText("");
        }
        
        if(e.getSource()==beq)
        {
            b=Double.parseDouble(t.getText());
        
            switch(operator)
            {
                case 1: result=a+b;
                    break;
        
                case 2: result=a-b;
                    break;
        
                case 3: result=a*b;
                    break;
        
                case 4: result=a/b;
                    break;
        
                default: result=0;
            }
	b=0;
	a=0;
        
            t.setText(""+result);
        }
        
        if(e.getSource()==bclr)
            t.setText("");
        
        if(e.getSource()==bdel)
        {
            String s=t.getText();
            t.setText("");
            for(int i=0;i<s.length()-1;i++)
            t.setText(t.getText()+s.charAt(i));
        }        

	}

	public static void main(String args[]){
		new SwingsCalculator();
	}

}


