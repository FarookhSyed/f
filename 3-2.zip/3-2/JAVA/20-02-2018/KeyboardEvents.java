import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
	<applet code="KeyboardEvents.class" width=800 height=400></applet>
*/

public class KeyboardEvents extends Applet implements KeyListener{
	String msg;
	public void init(){
		addKeyListener(this);
		requestFocus();
		msg="KeyEvents-->>";
	}
	public void paint(Graphics g){
		g.drawString(msg,20,20);
	}
	public void keyTyped(KeyEvent k){
		msg+=k.getKeyChar();
		showStatus("KEY TYPED");
		repaint();		
	}
	public void keyPressed(KeyEvent k){
		int key = k.getKeyCode();
		switch(key){
			case KeyEvent.VK_UP:
				showStatus("UP ARROW PRESSED");
				break;
			case KeyEvent.VK_DOWN:
				showStatus("DOWN ARROW PRESSED");
				break;
			case KeyEvent.VK_LEFT:
				showStatus("LEFT ARROW PRESSED");
				break;
			case KeyEvent.VK_RIGHT:
				showStatus("RIGHT ARROW PRESSED");
				break;
		}
		repaint();
	}
	public void keyReleased(KeyEvent k){
		showStatus("KEY RELEASED");
	}
}


