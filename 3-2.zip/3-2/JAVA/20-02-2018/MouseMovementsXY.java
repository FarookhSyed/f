import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
	<applet code="MouseMovementsXY.class" width=800 height=800></applet>
*/

public class MouseMovementsXY extends Applet implements MouseListener,MouseMotionListener{
	String msg;
	int x,y;
	public void init(){
		addMouseMotionListener(this);
		addMouseListener(this);
		x=0;
		y=0;
		msg="";
	}
	public void paint(Graphics g){
		g.drawOval(x-15,y-15,20,20);
		g.drawString(x+","+y,x+10,y-10);
		g.drawString(msg,x+10,y-20);
	}
	public void mouseDragged(MouseEvent m){
		msg="Mouse Dragged";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mouseExited(MouseEvent m){
		msg="Mouse Exited";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mouseEntered(MouseEvent m){
		msg="Mouse Entered";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mouseReleased(MouseEvent m){
		msg = "Mouse Released";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mouseMoved(MouseEvent m){
		msg = "Mouse Moved";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mousePressed(MouseEvent m){
		msg = "Mouse Pressed";
		x = m.getX();
		y = m.getY();
		repaint();
	}
	public void mouseClicked(MouseEvent m){
		msg = "Mouse Clicked";
		x = m.getX();
		y = m.getY();
		repaint();
	}
}


