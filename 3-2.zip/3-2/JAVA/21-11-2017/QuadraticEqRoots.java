import java.io.*;

class QuadraticEqRoots{
	public static void main(String args[])throws IOException{
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Expression should be in the Form A(x^2)+Bx+C=0 .");
		System.out.print("Enter Value of A:");
		String s = br.readLine();
		double A = Double.parseDouble(s);
		System.out.print("Enter Value of B:");
		s = br.readLine();
		double B = Double.parseDouble(s);
		System.out.print("Enter Value of C:");
		s= br.readLine();
		double C = Double.parseDouble(s);
		double D = (B*B)-(4*A*C);
		System.out.println("Delta Value is "+D);
		double Dsqrt = 0;
		if(D==0){
			System.out.println("Roots are Real and Equal.");
			Dsqrt = 0;
		}
		else if(D>0){
			System.out.println("Roots are Real and Distinct.");
			Dsqrt = Math.sqrt(D);
		}
		else{
			System.out.println("Roots are Imaginary.");
			Dsqrt = Math.sqrt(-1*D);
		}	
		System.out.println("Square Root of Delta Value is "+Dsqrt);
		double x1 = (-B+Dsqrt)/(2*A);
		double x2 = (-B-Dsqrt)/(2*A);
		System.out.println("Roots are "+x1+" and "+x2);
	}
}