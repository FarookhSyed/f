import java.io.*;

class CircleArea{
	public static void main(String args[])throws IOException{
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.print("Enter Radius(Real number only) :");
		String s = br.readLine();
		int r = Integer.parseInt(s);
		double area = (22/7)*r*r;
		System.out.println("Area of cirlce is "+area);
	}
}