import java.io.*;

class Biodata{
	public static void main(String args[]){
		System.out.println("Name: GOPINADH");
		System.out.println("RegNo: 16K61A05G7");
		System.out.println("Dept: CSE");
		System.out.println("Address: Tadepalligudem");
		System.out.println("Program: B.Tech");
	}
}