class EvenNum extends Thread{
	public void run(){
		try{sleep(500);}
		catch(Exception e){}
		int i=2;
		while(true){
			try{sleep(1000);}
			catch(Exception e){}
			int j=2;
			for(j=2;j<i;j++){
				if(i%j==0){
					break;
				}
			}
			if(i==2 || i==j){
					System.out.println("Prime-"+i);
			}
			else
				System.out.println("Even-"+i);
			i+=2;
		}
	}
}

class OddNum extends Thread{
	public void run(){
		int j=1;
		while(true){
			try{sleep(1000);}
			catch(Exception e){}
			int i=2;
			for(i=2;i<j;i++){
				if(j%i==0){
					break;
				}
			}
			if(j!=1 && i==j){
				System.out.println("Prime-"+j);
			}
			else
				System.out.println("Odd-"+j);
			j+=2;
		}
	}
}

class ThreadEvenOdd{
	public static void main(String args[]){
		EvenNum e = new EvenNum();

		OddNum o = new OddNum();

		e.start();
		o.start();
	}
}