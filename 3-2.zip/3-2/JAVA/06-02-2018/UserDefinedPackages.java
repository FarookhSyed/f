import MyAppOnArithematicOperations.*;
import java.util.*;


class UserDefinedPackages{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter Two Numbers:");
		int x = in.nextInt();
		int y = in.nextInt();
		Addition a = new Addition();
		a.meth(x,y);
		Subtraction b = new Subtraction();
		b.meth(x,y);
		Multiplication c = new Multiplication();
		c.meth(x,y);
		Division d = new Division();
		d.meth(x,y);
	}
}