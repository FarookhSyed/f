package MyAppOnArithematicOperations;

public class Subtraction{
	public void meth(int a,int b){
		System.out.println("Difference="+(a-b));
	}
}