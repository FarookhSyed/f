package MyAppOnArithematicOperations;

public class Addition{
	public void meth(int a,int b){
		System.out.println("Sum="+(a+b));
	}
}