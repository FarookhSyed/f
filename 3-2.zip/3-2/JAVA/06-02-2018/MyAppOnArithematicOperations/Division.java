package MyAppOnArithematicOperations;

public class Division{
	public void meth(int a,int b){
		System.out.println("Quotient="+(a/b));
	}
}