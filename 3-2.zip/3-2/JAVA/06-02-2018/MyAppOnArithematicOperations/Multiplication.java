package MyAppOnArithematicOperations;

public class Multiplication{
	public void meth(int a,int b){
		System.out.println("Product="+(a*b));
	}
}