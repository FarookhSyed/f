class SuperClass{
	public void show(){
		System.out.println("In SuperClass");
	}
}
class SubClass extends SuperClass{
	public void show(){
		super.show();
		System.out.println("In SubClass");
	}	
}
class KeywordSuperForMethod{
	public static void main(String args[]){
		SubClass ob = new SubClass();
		ob.show();
	}
}