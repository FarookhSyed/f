interface A{
	void showA();
}
interface B extends A{
	void showB();
}
class C implements B{
	public void showA(){
		System.out.println("A");
	}
	public void showB(){
		System.out.println("B");
	}
}
class ExtendInterface{
	public static void main(String args[]){
		C ob = new C();
		ob.showA();
		ob.showB();
	}
}