import java.io.*;
import java.util.*;

interface Shape{
	void area(double x);
	double PI = 22/7;
}

class CircleAreaCal implements Shape{
	public void area(double x){
		System.out.println("Area of Circle is "+(x*PI*x));
	}
}

class Circle{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		CircleAreaCal  ob = new CircleAreaCal();
		System.out.print("Enter Radius:");
		double x = in.nextDouble();
		ob.area(x);
	
	}

}