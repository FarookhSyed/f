import java.io.*;
import java.util.*;

class ImplementingFinally{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter size of Array:");
		int n = in.nextInt();
		int a[] =  new int[n];
		System.out.print("Enter Elements:");
		for(int i=0;i<n;i++)a[i]=in.nextInt();
		try{
			System.out.print("Enter Index to Access:");
			int temp = in.nextInt();
			System.out.print("Enter a value:");
			a[temp] = in.nextInt();
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Index doesn't Exist.");
		}
		finally{	
			int x=0;
			for(int i=0;i<n;i++)x+=a[i];
			System.out.println("Sum of the Elements in the Array:"+x);
		}
	}
}