import java.io.*;
import java.util.*;

class ImplementingThrow{
	static void exFun(int input){
		Scanner i;
		try{
			if(input==1)i = new Scanner(System.in);
			else throw new NullPointerException();
			System.out.print("Enter a String:");
			String s = i.nextLine();
			System.out.println("String is "+s);	
		}
		catch(NullPointerException e){
			System.out.println("NULL POINTER EXCEPTION IN METHOD");
			throw e;
		}
	}

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		try{
			System.out.print("To Enter a Input ( Press '1' ):");
			int temp = in.nextInt();
			exFun(temp);
		}
		catch(NullPointerException e){
			System.out.println("NULL POINTER EXCEPTION IN MAIN");
		}
	}
}