import java.io.*;
import java.util.*;

class UserDefinedException extends Exception{
	UserDefinedException(){
		super();
	}
	public void incorrectInput(){
		System.out.println("Incorrect input");
	}
}

class ImplementingUserDefinedException{

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		try{
			System.out.print("Enter a Number between (1-10):");
			int a  = in.nextInt();
			if(a<1 || a>10)throw new UserDefinedException();
			System.out.println("Number Entered is "+a);
		}
		catch(UserDefinedException e){
			e.incorrectInput();
		}
	}
}