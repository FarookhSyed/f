import java.io.*;
import PACK.*;

class ExPack{
	public static void main(String args[]){
		A a = new A();
		a.display();
		B b = new B();
		b.show();
	}
}