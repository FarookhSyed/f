import java.io.*;
import java.util.*;

class BuiltInExceptionsInJava{

	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		Scanner i;
		try{
			System.out.print("Enter 1 to take input:");
			int t = in.nextInt();
			if(t!=1)throw new NullPointerException();
			i = new Scanner(System.in);
			System.out.print("Enter a Number between 1-100:");
			t = i.nextInt();
			if(t<1 || t>100)throw new ArithmeticException();
			System.out.println("Given Number is "+t);
			
		}
		catch(NullPointerException e){
			System.out.println("Unable to Take input");
		}
		catch(ArithmeticException e){
			System.out.println("Incorrect input");
		}
	}
}