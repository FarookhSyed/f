import java.io.*;

class PrimitiveTypesValues{
	static byte by;
	static short sh;
	static int in;
	static long lo;
	static float fl;
	static double dou;
	static char ch;
	static boolean bo;
	public static void main(String args[]){
		System.out.println("Default Value of Byte is "+by);
		System.out.println("Default Value of Short is "+sh);
		System.out.println("Default Value of Int is "+in);
		System.out.println("Default Value of Long is "+lo);
		System.out.println("Default Value of float is "+fl);
		System.out.println("Default Value of Double is "+dou);
		System.out.println("Default Value of Char is "+ch);
		System.out.println("Default Value of Boolean is "+bo);
	}
}