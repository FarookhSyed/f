import java.io.*;

class BinarySearch{
	public static void main(String args[])throws IOException{
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		String s;
		System.out.print("Enter the Size of the Array:");
		s = br.readLine();
		int n = Integer.parseInt(s);
		int elements[] = new int[n];
		System.out.println("Enter the Integer Elements:");
		for(int i=0;i<n;i++){
			s = br.readLine();
			int value = Integer.parseInt(s);
			elements[i] = value;
		}
		System.out.print("Enter the Value to to Search:");
		s = br.readLine();
		int key = Integer.parseInt(s);
		int low = 0;
		int high = n-1;
		int mid = 0;
		while(low<=high){
			mid = (low+high)/2;
			if(elements[mid]==key){
				s = "Found";
				break;
			}
			if(key<elements[mid]){
				high=mid-1;
			}
			else{
				low=mid+1;
			}
		}
		if(s=="Found"){
			System.out.println("Element Found at Position "+(mid+1));
		}
		else{
			System.out.println("Element NOT Found");
		}
	}
}