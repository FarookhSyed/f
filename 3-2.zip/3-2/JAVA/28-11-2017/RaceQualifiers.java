import java.io.*;

class RaceQualifiers{
	public static void main(String args[])throws IOException{
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		double biker[] = new double[5]; 
		double avg = 0;
		for(int i=0;i<5;i++){
			System.out.print("Enter the Speed of Biker_"+(i+1)+":");
			String s = br.readLine();
			double speed = Double.parseDouble(s);
			biker[i] = speed;
			avg = avg+(speed/5);
		}
		for(int i=0;i<5;i++){
			if(biker[i]>avg){
				System.out.println("Biker_"+(i+1)+" will be Qualified.");
			}
		}
	}
}