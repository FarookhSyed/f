import java.io.*;

class BubbleSort{
	public static void main(String args[])throws IOException{
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		String s;
		System.out.print("Enter the Size of the Array:");
		s = br.readLine();
		int n = Integer.parseInt(s);
		int elements[] = new int[n];
		System.out.println("Enter the Integer Elements:");
		for(int i=0;i<n;i++){
			s = br.readLine();
			int value = Integer.parseInt(s);
			elements[i] = value;		
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n-i-1;j++){
					if(elements[j]>elements[j+1]){
						int temp = elements[j];
						elements[j] = elements[j+1];
						elements[j+1] = temp;
					}
			}
		}
		System.out.println("Elements after Sorting");
		for(int i=0;i<n;i++){
			System.out.print(elements[i]+" ");
		}
	}
}