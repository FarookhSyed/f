import java.io.*;
import java.util.Scanner;

class MergeSort{
	static int[] a = new int[0];
	static int n;

	static void mergesort(int low,int mid,int high){
		int i,j,k;
		i=low;
		j=low;
		k=mid+1;
		int[] b = new int[n];
		while(i<mid+1 && k<=high){
			if(a[i]<a[k]){
				b[j]=a[i];
				i++;j++;	
			}
			else{
				b[j]=a[k];
				k++;j++;
			}
		}
		while(i<mid+1){
			b[j]=a[i];
			j++;i++;
		}
		while(k<=high){
			b[j]=a[k];
			k++;j++;	
		}
		for(i=low;i<k;i++){
			a[i]=b[i];
		}
	}

	static void merge(int low,int high){
		if(low<high){
			int mid = (low+high)/2;
			merge(low,mid);
			merge(mid+1,high);
			mergesort(low,mid,high);
		}
	}
	
	public static void main(String agrs[]){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the Size of the Elements:");
		n = in.nextInt();
		a = new int[n];
		System.out.println("Enter the Elements:-");
		for(int i=0;i<n;i++){
			a[i] = in.nextInt();
		}
		merge(0,n-1);
		System.out.println("Sorted Elements are ");
		for(int i=0;i<n;i++){
			System.out.print(a[i]+" ");
		}
	}
}