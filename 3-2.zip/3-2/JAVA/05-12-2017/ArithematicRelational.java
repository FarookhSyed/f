import java.io.*;
import java.util.Scanner;

class ArithematicRelational{
	public static void main(String args[]){
		int a,b,c;
		Scanner in = new Scanner(System.in);
		System.out.print("Enter int Values of two Numbers:");
		a=in.nextInt();
		b=in.nextInt();
		System.out.println("a+b is "+(a+b));
		System.out.println("a-b is "+(a-b));
		System.out.println("a*b is "+(a*b));
		System.out.println("a/b is "+(a/b));
		System.out.println("a%b is "+(a%b));
		System.out.println("a==b is "+(a==b));
		System.out.println("a!=b is "+(a!=b));
		System.out.println("a>b is "+(a>b));
		System.out.println("a<b is "+(a<b));
		System.out.println("a>=b is "+(a>=b));
		System.out.println("a<=b is "+(a<=b));
	}
}