import java.io.*;
import java.util.Scanner;

class StringOperations{

	static InputStreamReader isr = new InputStreamReader(System.in);
	static BufferedReader br = new BufferedReader(isr);
	static Scanner in = new Scanner(System.in);

	public static void main(String args[])throws IOException{
		System.out.print("Enter the String:");
		String s = br.readLine();
		StringBuffer sb = new StringBuffer(s);
		System.out.print("Enter String to Insert:");
		s = br.readLine();

		int[] p = new int[2];
		System.out.print("Enter Position to insert the String:");
		p[0] = in.nextInt();
		sb.insert(p[0],s);
		System.out.println("Now String is "+sb);

		System.out.print("Enter Positions(begining,ending) to Remove the String:");
		p[0] = in.nextInt();
		p[1] = in.nextInt();
		sb.delete(p[0],p[1]+1);
		System.out.println("Now String is "+sb);

		System.out.print("Enter Position to Remove a Character:");
		p[0] = in.nextInt();
		sb.deleteCharAt(p[0]);
		System.out.println("Now String is "+sb);

		
	}
}