import java.applet.*;
import java.awt.*;

/*
	<applet code="LifeCycleApplet.class" width=800 height=800></applet>
*/

public class LifeCycleApplet extends Applet{
	String msg;
	public void paint(Graphics g){
		msg = "Applet running"
		g.drawString(msg,x,y);
		y+=20;
	}
	public void start(){
		x = 10;
		y = 10;
		msg ="Applet Created";
	}

}