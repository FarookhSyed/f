import java.applet.*;
import java.awt.*;

/* <applet code="AppletParamPassing" width=500 height=500>
		<param name=yourAge value=35/>
		<param name=yourName value=John/>
	</applet>
*/

public class AppletParamPassing extends Applet{
	String name,age;
	public void start(){
		name = getParameter("yourName");
		if(name == null)name = "not found";
		age = getParameter("yourAge");
		if(age==null)age = "0";
	}
	public void paint(Graphics g){
		g.drawString("your name:"+name,10,10);
		g.drawString("your age:"+age,20,20);
	}
}