import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.applet.*;
import java.text.*;

class DigitalClockSwings extends Thread{
	JFrame f;
	JTextField hours,minutes,seconds;
	
	DigitalClockSwings(){
		f = new JFrame("DigitalClock");
		hours = new JTextField();
		minutes = new JTextField();
		seconds = new JTextField();
		hours.setBounds(10,25,50,50);
		minutes.setBounds(60,25,50,50);
		seconds.setBounds(110,25,50,50);
		f.add(hours);
		f.add(minutes);
		f.add(seconds);
		f.setLayout(null);
		f.setVisible(true);
		f.setSize(200,120);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setResizable(false);
	}
	
	public void run(){
		while(true){
			try{
				Calendar cal = Calendar.getInstance();
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				if(hr>12)hr-=12;
				hours.setText(" "+hr+" : ");
				int min = cal.get(Calendar.MINUTE);
				minutes.setText(" "+min+" : ");
				int sec = cal.get(Calendar.SECOND);
				seconds.setText(" "+sec+" ");
			}
			catch(Exception e){}
		}
	}
	
	public static void main(String args[]){
		DigitalClockSwings obj = new DigitalClockSwings();
		obj.start();
	}
}