class A extends Thread{
	public void run(){
		System.out.println(Thread.currentThread().getName()+" Started Thread");
		try{
			sleep(1000);
		}
		catch(Exception e){}
		System.out.println(Thread.currentThread().getName()+" Exited Thread");
	}
}
class AliveJoinImplementation{
	public static void main(String args[]){
		A t1 = new A();
		A t2 = new A();

		t1.start();
		System.out.println("Threads Alive A:"+t1.isAlive()+" B:"+t2.isAlive());
		try{
			t1.join();
		}
		catch(Exception e){}
		t2.start();
	
	}

}