class DaemonThreadImplementation extends Thread{
	public void run(){
		if(Thread.currentThread().isDaemon()){
			System.out.println("Daemon Thread Executed");
		}
		else
			System.out.println("user(normal) Thread Executed");
	}
	public static void main(String args[]){
		DaemonThreadImplementation t1 = new DaemonThreadImplementation();
		DaemonThreadImplementation t2 = new DaemonThreadImplementation();
		t1.setDaemon(true);
		t1.start();
		t2.start();
	}
}