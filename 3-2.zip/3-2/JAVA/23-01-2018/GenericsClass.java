import java.util.*;
class GenericsClass <T> {
	public void A(){
		Scanner in = new Scanner(System.in);
		int a = in.nextInt();
		T x = a;
	}

	public static void main(String args[]){
		
		GenericsClass x  = new GenericsClass();
		x.A();
	}
}