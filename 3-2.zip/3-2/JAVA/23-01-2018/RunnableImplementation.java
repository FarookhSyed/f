class A implements Runnable{
	Thread t1;
	A(){
		t1 = new Thread(this);
		t1.start();
	}
	public void run(){
		try{
			while(true){
				Thread.sleep(1000);
				System.out.println("Good Morning");
			}
		}
		catch(Exception e){}
	}
}
class B implements Runnable{
	Thread t2;
	B(){
		t2 = new Thread(this);
		t2.start();
	}
	public void run(){
		try{
			while(true){
				Thread.sleep(2000);
				System.out.println("Hello");
			}
		}
		catch(Exception e){}
	}
}
class C implements Runnable{
	Thread t3;
	C(){
		t3 = new Thread(this);
		t3.start();
	}
	public void run(){
		try{
			while(true){
				Thread.sleep(3000);
				System.out.println("Welcome");
			}
		}
		catch(Exception e){}
	}
}
class RunnableImplementation{
	public static void main(String args[]){
		A t1 = new A();
		B t2 = new B();
		C t3 = new C();	
	}
}