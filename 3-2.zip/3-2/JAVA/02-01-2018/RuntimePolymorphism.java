import java.io.*;
import java.util.*;

class A{
	public void display(){
		System.out.println("In Class A");
	}
}
class B extends A{
	public void display(){
		System.out.println("In Class B");
	}
}
class C extends A{
	public void display(){
		System.out.println("In Class C");
	}
}

class RuntimePolymorphism{
	public static void main(String args[]){
		A a = new A();
		B b = new B();
		C c = new C();
		A x;
		x = a; x.display();
		x = b; x.display();
		x = c; x.display();
	}
}