import java.io.*;
import java.util.*;

class MultipleCatchClauses{
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		try{
			int a = args.length ; 
			int x =0;
			for(int i=0;i<a;i++){
				int t = Integer.parseInt(args[i]);
				x += t;
			}
			System.out.print("Enter Index:");
			int b = in.nextInt();
			System.out.println("Element at Index is "+args[b]);
			System.out.print("Enter Number to divide :");
			int t = in.nextInt();
			System.out.println(Integer.parseInt(args[b])/t);
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("INDEX DOES'NT EXIST.");
		}
		catch(ArithmeticException e){
			System.out.println("NOT POSSIBLE TO DIVIDE WITH ZERO.");
		}
	}
}