import java.io.*;
import java.util.*;

class OuterClass{
	static int x =5;
	int z = 15;
	static class InnerClass{
		static int y = 10;
		int w = 20;
		static void staticMethodIn(){
			System.out.println("Inner Static");
			System.out.println("Outer Static Variable:"+x);
		}
		void nonStaticMethodIn(){
			System.out.println("Inner Non-Static");
		}
	}
	static void staticMethodOt(){
		InnerClass.staticMethodIn();
		System.out.println("Inner Static Variable:"+InnerClass.y);
		System.out.println("Outer Static");
	}
	void nonStaticMethodOt(){
		InnerClass ob =  new InnerClass();
		ob.nonStaticMethodIn();
		System.out.println("Inner Non-Static Variable:"+ob.w);
		System.out.println("Outer Non-Static");
	}	
}
 
class StaticNestedClasses{
	public static void main(String args[]){
		OuterClass ob = new OuterClass();
		ob.nonStaticMethodOt();
		ob.staticMethodOt();
	}
}