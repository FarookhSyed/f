import java.io.*;
import java.util.*;

class StringCompare{
	public static void main(String args[]){
		int l = args.length;
		for(int i=0;i<l;i++){
			for(int j=0;j<l-i-1;j++){
				int x = args[j].compareTo(args[j+1]);
				if(x>0){
					System.out.println(x);
					String t = args[j];
					args[j] = args[j+1];
					args[j+1] = t;
				}
			}
		}
		for(int i=0;i<l;i++){
			System.out.print(args[i]+" ");
		}
	}
}