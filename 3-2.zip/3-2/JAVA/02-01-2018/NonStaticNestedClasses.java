import java.io.*;
import java.util.*;

class OuterClass{
	static int x =5;
	int z = 15;
	class InnerClass{
		int w = 20;
		void nonStaticMethodIn(){
			System.out.println("Inner Non-Static");
		}
	}
	static void staticMethodOt(){
		System.out.println("Outer Static");
	}
	void nonStaticMethodOt(){
		InnerClass ob =  new InnerClass();
		ob.nonStaticMethodIn();
		System.out.println("Inner Non-Static Variable:"+ob.w);
		System.out.println("Outer Non-Static");
	}	
}
 
class NonStaticNestedClasses{
	public static void main(String args[]){
		OuterClass ob = new OuterClass();
		ob.nonStaticMethodOt();
		OuterClass.staticMethodOt();
	}
}