import java.io.*;
import java.util.Scanner;

class StudentDetails{
	String name;
	String regno;
	public void setStudentDetails(String s,String r){
		name = s;
		regno = r;
	}

	public void showStudentDetails(){
		System.out.println("Name of the Student is "+name+", Reg.No is "+regno);
	}	


}

class StudentGrade extends StudentDetails{

	char G;
	double percent;

	public void setStudentGrade(int sum){
		percent = (sum/600)*100;
		if(percent>70)G='A';
		else if(percent>60)G='B';
		else if(percent>50)G='C';
		else G='F';
		
	}
	
	public void showGradeofStudent(){
		System.out.println("Grade of Student is "+G);
	}

}

class StudentMarks extends StudentGrade{
	Scanner in =new Scanner(System.in);
	int m[] = new int[6];
	int avg = 0,sum = 0;
	StudentMarks(){
		System.out.print("Enter the Marks of Six Subjects:");
		for(int i=0;i<6;i++){
			m[i] = in.nextInt();
			sum = sum+m[i];
			avg = avg+(m[i]/6);
		}
	}
	
	public void showAvgofMarks(){
		System.out.println("Average of Marks is "+avg);
	}

}



class MultilevelInheritance{
	public static void main(String args[])throws IOException{
		Scanner in =new Scanner(System.in);
		InputStreamReader isr =  new InputStreamReader(System.in);
		BufferedReader br =  new BufferedReader(isr);

		System.out.print("Enter the Name:");
		String name = br.readLine();
		System.out.print("Enter the Reg.No:");
		String regno = br.readLine();

		StudentMarks stu = new StudentMarks();
		stu.setStudentDetails(name,regno);
		stu.setStudentGrade(stu.sum);
		stu.showStudentDetails();
		stu.showAvgofMarks();
		stu.showGradeofStudent();
		
	}
}