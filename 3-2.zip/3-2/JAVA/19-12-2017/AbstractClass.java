import java.io.*;
import java.util.Scanner;

abstract class Shape{
	abstract public void area();
}

class Rectangle extends Shape{

	int l,b;
	
	Rectangle(int x,int y){
		l=x;b=y;
	}
	
	public void area(){
		System.out.println("Area of Rectangle is "+(l*b));
	}

}

class Circle extends Shape{

	int r;
	
	Circle(int x){
		r=x;
	}
	
	public void area(){
		System.out.println("Area of Rectangle is "+(3.14*r*r));
	}

}


class AbstractClass{
	public static void main(String args[])throws IOException{
		Scanner in =new Scanner(System.in);

		System.out.print("Enter the Length and Breadth of Rectangle:");
		int a = in.nextInt();
		int b = in.nextInt();
		Rectangle r = new Rectangle(a,b);
		r.area();

		System.out.print("Enter the Radius of Circle:");
		a = in.nextInt();
		Circle c = new Circle(a);
		c.area();
		
	}
}