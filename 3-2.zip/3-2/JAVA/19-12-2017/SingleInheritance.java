import java.io.*;
import java.util.Scanner;

class StudentDetails{
	String name;
	String regno;
	public void setStudentDetails(String s,String r){
		name = s;
		regno = r;
	}

	public void showStudentDetails(){
		System.out.println("Name of the Student is "+name+", Reg.No is "+regno);
	}	


}

class StudentMarks extends StudentDetails{
	Scanner in =new Scanner(System.in);
	int m[] = new int[6];
	int avg = 0;
	StudentMarks(){
		System.out.print("Enter the Marks of Six Subjects:");
		for(int i=0;i<6;i++){
			m[i] = in.nextInt();
			avg = avg+(m[i]/6);
		}
	}
	
	public void showAvgofMarks(){
		System.out.println("Average of Marks is "+avg);
	}

}

class SingleInheritance{
	public static void main(String args[])throws IOException{
		Scanner in =new Scanner(System.in);
		InputStreamReader isr =  new InputStreamReader(System.in);
		BufferedReader br =  new BufferedReader(isr);

		System.out.print("Enter the Name:");
		String name = br.readLine();
		System.out.print("Enter the Reg.No:");
		String regno = br.readLine();

		StudentMarks stu = new StudentMarks();
		stu.setStudentDetails(name,regno);
		stu.showStudentDetails();
		stu.showAvgofMarks();
		
	}
}