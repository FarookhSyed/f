from selenium import webdriver
import time

chrome_path = 'C:\softwares for 2-2,3-2\chromedriver.exe'

driver = webdriver.Chrome(chrome_path)

driver.maximize_window()

driver.implicitly_wait(5)
driver.get('http://www.youtube.com/DevelopersWork')
time.sleep(10)
driver.get_screenshot_as_file("output.png");

driver.get('http://developersworkofficial.tk')

time.sleep(40)

driver.quit()
