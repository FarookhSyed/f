#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>

#include "users.c"
#include "books.c"
#include "transaction.c"

int login(char *buffer1,char *buffer2){
	char username[10] = "admin\0";
	char password[50] = "abcd\0";
	// char buffer1[1024],buffer2[1024];

login:
	// printf("Enter username: ");
	// fgets(buffer1,10,stdin);
	// printf("Enter password: ");
	// fgets(buffer2,50,stdin);
	if(strncmp(buffer1,username,strlen(username))!=0){
		// goto login;
		return 0;
	}
	if(strncmp(buffer2,password,strlen(password))!=0){
		// goto login;
		return 0;
	}
	return 1;
}
