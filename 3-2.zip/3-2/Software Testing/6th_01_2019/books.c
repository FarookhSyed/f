struct Book{
	char ISBN[10];
	char name[100];
	char author[100];
	int edition,volume,pages,cost;
}books_db[5];
int total_books = 0;

int createBook(struct Book b){
	if(total_books == 4){
		return 0;
	}
	char buffer[1024];
	b1:	// printf("ISBN: ");
		// scanf("%s",buffer);
		strcpy(buffer,b.ISBN);
		if(!atoi(buffer)){
			goto b1;
		}
	if(searchBook(buffer)>-1)
		return 0;
	buffer[strlen(buffer)] = '\0';
	strcpy(books_db[total_books].ISBN,buffer);
	
	// printf("Name: ");
	// scanf(" ");
	// gets(buffer);
	// buffer[strlen(buffer)] = '\0';
	strcpy(books_db[total_books].name,b.name);
	
	// printf("Author: ");
	// scanf(" ");
	// gets(buffer);
	// buffer[strlen(buffer)] = '\0';
	strcpy(books_db[total_books].author,b.author);
	
	// int temp;
	// printf("Edition: ");
	// scanf("%d",&temp);
	books_db[total_books].edition = b.edition;
	
	// printf("Volume: ");
	// scanf("%d",&temp);
	books_db[total_books].volume = b.volume;
	
	// printf("Pages: ");
	// scanf("%d",&temp);
	books_db[total_books].pages = b.pages;
	
	// printf("Cost: ");
	// scanf("%d",&temp);
	books_db[total_books].cost = b.cost;
	
	total_books++;
	
	return 1;
}

int searchBook(char *ISBN){
	int i=0;
	for(i=0;i<total_books;i++){
		if(strcmp(books_db[i].ISBN,ISBN)==0){
			return i;
		}
	}
	return -1;
}

int viewBook(struct Book b){
	char buffer[1024];
	b2:	// printf("ISBN: ");
		// scanf("%s",buffer);
		strcpy(buffer,b.ISBN);
		if(!atoi(buffer)){
			goto b2;
		}
	int i = 0;
	if((i = searchBook(buffer))<0)
		return 0;
	
	printf("Name: %s\n",books_db[i].name);
	printf("Author: %s\n",books_db[i].author);
	printf("Edition: %d\n",books_db[i].edition);
	printf("Volume: %d\n",books_db[i].volume);
	printf("Pages: %d\n",books_db[i].pages);
	printf("Cost: %d\n",books_db[i].cost);
	
	return 1;
}

int updateBook(struct Book b){
	char buffer[1024];
	b3:	// printf("ISBN: ");
		// scanf("%s",buffer);
		strcpy(buffer,b.ISBN);
		if(!atoi(buffer)){
			goto b3;
		}
	int i = 0;
	if((i = searchBook(buffer))==-1)
		return 0;
	
	// printf("ENTER $ FOR DEFAULT\n");
	
	// printf("Name: ");
	// scanf(" ");
	// gets(buffer);
	strcpy(buffer,b.name);
	buffer[strlen(buffer)] = '\0';
	if(strcmp(buffer,"$")!=0)
		strcpy(books_db[i].name,buffer);
	
	// printf("Author: ");
	// scanf(" ");
	// gets(buffer);
	strcpy(buffer,b.author);
	buffer[strlen(buffer)] = '\0';
	if(strcmp(buffer,"$")!=0)
		strcpy(books_db[i].author,buffer);
	
	// printf("Edition: ");
	// scanf("%s",buffer);
	if(b.edition>0)
		books_db[i].edition = b.edition;
	
	// printf("Volume: ");
	// scanf("%s",buffer);
	// buffer[strlen(buffer)] = '\0';
	if(b.volume>0)
		books_db[i].volume = b.volume;
	
	// printf("Pages: ");
	// scanf("%s",buffer);
	// buffer[strlen(buffer)] = '\0';
	if(b.pages>0)
		books_db[i].pages = b.pages;
	
	// printf("Cost: ");
	// scanf("%s",buffer);
	// buffer[strlen(buffer)] = '\0';
	if(b.cost>0)
		books_db[i].cost = b.cost;
	
	return 1;
}
