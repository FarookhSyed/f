
struct User{
	char reg_no[11];
	char name[100];
	char branch[50];
	char batch[10];
	int transactions;
}users_db[5];
int total_users = 0;

void strupr( char *p ) 
{ 
	while( *p ) 
	{ 
		*p=toupper( *p ); 
		p++; 
	}
}

int createUser(struct User u){
	if(total_users == 4){
		return 0;
	}
	char buffer[1024];
	u1:	// printf("Reg.no: ");
		// scanf("%s",buffer);
		strcpy(buffer,u.reg_no);
		if(strlen(buffer)!=10){
			goto u1;
		}
	strupr(buffer);
	if(searchUser(buffer)>-1)
		return 0;
	buffer[10] = '\0';
	strncpy(users_db[total_users].reg_no,buffer,10);
	
	// printf("Name: ");
	// scanf(" ");
	// gets(buffer);
	strcpy(users_db[total_users].name,u.name);
	
	// printf("Branch: ");
	// scanf("%s",buffer);
	strcpy(users_db[total_users].branch,u.branch);
	
	// printf("Batch: ");
	// scanf("%s",buffer);
	strcpy(users_db[total_users].batch,u.batch);
	
	users_db[total_users].transactions = 0;
	total_users++;
	
	return 1;
}

int searchUser(char *regno){
	int i=0;
	for(i=0;i<total_users;i++){
		if(strcmp(users_db[i].reg_no,regno)==0){
			return i;
		}
	}
	return -1;
}

int viewUser(struct User u){
	char buffer[1024];
	u2:	// printf("Reg.no: ");
		// scanf("%s",buffer);
		strcpy(buffer,u.reg_no);
		if(strlen(buffer)!=10){
			goto u2;
		}
	strupr(buffer);
	int i = 0;
	buffer[10]='\0';
	if((i = searchUser(buffer))<0)
		return 0;
	
	printf("Name: %s\n",users_db[i].name);
	
	printf("Branch: %s\n",users_db[i].branch);
	
	printf("Batch: %s\n",users_db[i].batch);
	
	return 1;
}

int updateUser(struct User u){
	char buffer[1024];
	u3:	// printf("Reg.no: ");
		// scanf("%s",buffer);
		strcpy(buffer,u.reg_no);
		if(strlen(buffer)!=10){
			goto u3;
		}
	strupr(buffer);
	int i = 0;
	buffer[10]='\0';
	if((i = searchUser(buffer))==-1)
		return 0;
	
	// printf("ENTER $ FOR DEFAULT\n");
	// printf("Name: ");
	// scanf(" ");
	// gets(buffer);
	if(strcmp(u.name,"$")!=0)
		strcpy(users_db[i].name,u.name);
	
	// printf("Branch: ");
	// scanf("%s",buffer);
	if(strcmp(u.branch,"$")!=0)
		strcpy(users_db[i].branch,u.branch);
	
	// printf("Batch: ");
	// scanf("%s",buffer);
	if(strcmp(u.batch,"$")!=0)
		strcpy(users_db[i].batch,u.batch);
	
	return 1;
}
