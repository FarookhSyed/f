#include "library.c"

#include<Cunit/Cunit.h>

void testLogin(){
    CU_ASSERT(login("admi","abcd") == 0);
    
    CU_ASSERT(login("admin","abce") == 0);

    CU_ASSERT(login("admin","abcd") == 1);
}

main(){}