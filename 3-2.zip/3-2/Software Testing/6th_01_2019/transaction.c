struct Transaction{
	char ISBN[10];
	char reg_no[10];
	int alive;
}transactions_db[5];
int total_transactions = 0;

int searchTransaction(char *ISBN){
	int i=0;
	for(i=0;i<total_transactions;i++){
		if(strcmp(transactions_db[i].ISBN,ISBN)==0){
			return i;
		}
	}
	return -1;
}

int issueBook(struct Transaction t){
	if(total_transactions == 4){
		return 0;
	}
	char buffer1[1024];
	t1:	// printf("ISBN: ");
		// scanf("%s",buffer1);
		strcpy(buffer1,t.ISBN);
		if(!atoi(buffer1)){
			goto t1;
		}
	if(searchBook(buffer1)==-1)
		return 0;
	if(searchTransaction(buffer1)!=-1)
		return 0;
	buffer1[strlen(buffer1)] = '\0';

	char buffer[1024];
	t2:	// printf("Reg.no: ");
		// scanf("%s",buffer);
		strcpy(buffer,t.reg_no);
		if(strlen(buffer)!=10){
			goto t2;
		}
	strupr(buffer);
	if(searchUser(buffer)==-1)
		return 0;
	buffer[10] = '\0';

	int i;
	if((i = searchTransaction("$"))==-1)
		i = total_transactions++;

	strncpy(transactions_db[i].reg_no,buffer,10);
	strcpy(transactions_db[i].ISBN,buffer1);

	return 1;
}

void listTransactions(){
	int i=0;
	printf("ISBN\t\tREGNO\n");
	for(i=0;i<total_transactions;i++){
		if(strcmp(transactions_db[i].ISBN,"$")==0)
			continue;
		printf("%s\t\t%s\n",transactions_db[i].ISBN,transactions_db[i].reg_no);
	}
}

int returnBook(struct Transaction t){
	char buffer[1024];
	l2:	// printf("ISBN: ");
		// scanf("%s",buffer);
		strcpy(buffer,t.ISBN);
		if(!atoi(buffer)){
			goto l2;
		}
	int i = 0;
	if((i = searchTransaction(buffer))==-1)
		return 0;

	strcpy(transactions_db[i].ISBN,"$");
	
	return 1;
}
