data = open("train.csv").readlines()
data2 = []
for i in data:
    s = ""
    count = 0
    for j in i:
        if j == '"':
            count += 1
        if count == 0 or count == 2:
            s+=j
    data2.append(s)
data = data2
print data[0]
data = data[1::]
print data[0]
data = [i.split('\n')[0].split(',') for i in data]
train = data[1:len(data)/3]
print train[0]