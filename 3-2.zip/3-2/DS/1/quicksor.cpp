#include<iostream.h>
int n;
void quicksort(int [],int ,int);
int partition(int [],int ,int );
int main(){
	int a[50],i;
	cout<<"Enter Elements Range:";
	cin>>n;
	cout<<"Enter the Elements to the Range:-\n";
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	quicksort(a,0,n-1);
	cout<<"\n\nElements after Final Sort :-\n";
	for(i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
	return 0;
}

void quicksort(int a[],int p,int q){
	int j;
	if(p<q){
		j=partition(a,p,q);
		quicksort(a,p,j-1);
		quicksort(a,j+1,q);
	}
}

int partition(int a[],int p,int q){
	int i,j,temp,v;
	v=a[p];
	i=p;
	j=q+1;
	do{
		do{
			i++;
		}while(a[i]<v && i<=q);
		do{
			j--;
		}while(a[j]>v);
		if(i<j){
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
         cout<<"\nEelements after Swap:-\n";
			for(int k=0;k<n;k++){
				cout<<a[k]<<" ";
			}
		}
	}while(i<j);
	a[p]=a[j];
	a[j]=v;
	return(j);
}

