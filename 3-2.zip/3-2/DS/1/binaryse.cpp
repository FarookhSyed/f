#include<iostream.h>

int main(){
	int n;
	cout<<"Enter the Range of the Elements:";
	cin>>n;
	int a[10];
	cout<<"Enter the Elements\n";
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	cout<<"Enter the Key Value:";
	int key;
   cin>>key;
	int low=0,high=n-1,p=0,mid=0;
	while(low<=high){
		mid=(low+high)/2;
		if(key==a[mid]){
			p=1;
			break;
		}
		if(key<a[mid])
			high = mid-1;
		else
			low=mid+1;
	}
	if(p==0)
		cout<<"Element not Found.\n";
	else
		cout<<"Element Found.\n";
	return 0;
}

