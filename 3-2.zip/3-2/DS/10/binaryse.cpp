#include<iostream.h>
struct TreeNode{
	int value;
	struct TreeNode *right;
	struct TreeNode *left;
};
class BinaryTree{
	public:
		BinaryTree();
		void Insert(int);
		void Delete(int);
		void searchTree(int val,TreeNode *T);
		void searchTree(int);
		void Display();
		void Inorder(TreeNode *T);
		void Preorder(TreeNode *T);
		void Postorder(TreeNode *T);
	private:
		struct TreeNode *root,*newNode,*ptr;
		int Treecapacity;
};
BinaryTree::BinaryTree(){
	root=NULL;
}
void BinaryTree::Inorder(TreeNode *T){
	if(T->left!=NULL)
		Inorder(T->left);
	cout<<T->value<<" ";
	if(T->right!=NULL)
		Inorder(T->right);
}
void BinaryTree::Preorder(TreeNode *T){
	cout<<T->value<<" ";
	if(T->left!=NULL)
		Preorder(T->left);
	if(T->right!=NULL)
		Preorder(T->right);
}
void BinaryTree::Postorder(TreeNode *T){
	if(T->left!=NULL)
		Postorder(T->left);
	if(T->right!=NULL)
		Postorder(T->right);
	cout<<T->value<<" ";
}
void BinaryTree::Display(){
	if(!root){
		cout<<"Tree is Empty.";
	}
	else{
		int c;
		cout<<"\nAvaliable Options:-\n\t1.InOrder\n\t2.PreOrder\n\t3.PostOrder\nEnter your Choice:";
		cin>>c;
		ptr=root;
		switch(c){
			case 1:
				Inorder(ptr);
				break;
			case 2:
				Preorder(ptr);
				break;
			case 3:
				Postorder(ptr);
				break;
			default:
				cout<<"NOT A CORRECT CHOICE.";
		}
	}
}
void BinaryTree::searchTree(int val){
	searchTree(val,root);
	cout<<"After Search we Found:"<<ptr->value<<". Matches given Element in Tree.";
}
void BinaryTree::searchTree(int val,TreeNode *T){
	//cout<<T->value<<" ";
	if(val>T->value && T->right!=NULL){
		searchTree(val,T->right);
	}
	else if(val<T->value && T->left!=NULL){
		searchTree(val,T->left);
	}
	if(!T->right || !T->left || val==T->value){
		ptr=T;
	}
}
void BinaryTree::Insert(int e){
	newNode=new struct TreeNode;
	newNode->value=e;
	newNode->left=NULL;
	newNode->right=NULL;
	if(!root){
		root=newNode;
	}
	else{
		searchTree(e,root);
		if(e>ptr->value){
			ptr->right=newNode;
		}
		else if(e<ptr->value){
			ptr->left=newNode;
		}
	}
	ptr=root;
}
void BinaryTree::Delete(int e){
	if(!root){
		cout<<"Tree is NULL.";
	}
	else{
		searchTree(e,root);
		if(e==ptr->value){
			newNode=ptr->right;
			newNode->left=ptr->left;
			delete ptr;
			ptr=newNode;
		}
		else{
      	cout<<"Given value is Not Found.";
		}
	}
}
int main(){
	BinaryTree BT;
	int c,item;
	while(1){
		cout<<"\nAvailable Options:-\n\t1.Insert\n\t2.Delete\n\t3.Search Element\n\t4.Display\n\t5.Exit\nEnter your Choice:";
		cin>>c;
		switch(c){
			case 1:
				cout<<"Enter Element to Insert:";
				cin>>item;
				BT.Insert(item);
				break;
			case 2:
				cout<<"Enter Element to Delete:";
				cin>>item;
				BT.Delete(item);
				break;
			case 3:
				cout<<"Enter Element to Search:";
				cin>>item;
				BT.searchTree(item);
				break;
			case 4:
         	BT.Display();
				break;
			case 5:
				return 1;
			default:
				cout<<"Re-Enter....";
		}
	}
	//return 1;
}
