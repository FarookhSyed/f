#include<iostream.h>
int gameOver;
void setup(){
	gameOver=0;
	for(int i=0;i<20;i++){
		for(int j=0;j<100;j++){
			if(i==0 || j==0 || i==19 || j==99){
				cout<<"#";
			}
			else cout<<" ";
		}
      cout<<endl;
	}
	gameOver=1;
}
int main(){
	setup();
	while(!gameOver){

	}
   return 0;
}