#include<iostream.h>
int g[10][10],visited[10],n,v;
void DFS(int i){
	int j;
	cout<<i<<"\t";
	visited[i]=1;
	for(j=0;j<n;j++){
		if(visited[j]==0&&g[i][j]!=0){
			DFS(j);
		}
	}
}
void main(){
	int i,j;
	cout<<"Enter Number of Vertices:";
	cin>>n;
	cout<<"Enter adjacent matrix of the graph:";
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			cin>>g[i][j];
		}
	}
   for(i=0;i<n;i++){
		visited[i]=0;
	}
	cout<<"Enter the Source Vertex:";
	cin>>v;
   DFS(v);
}
