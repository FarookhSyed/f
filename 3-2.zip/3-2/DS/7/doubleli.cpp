#include<iostream>
using namespace std;
struct node{
  int data;
  struct node *pre;
  struct node *next;
};
class DoubleLinkedList{
	public:
		DoubleLinkedList();
		void Insert(int);
		void Delete(int);
		void Reverse();
		void Display();
		void options();
		node *createNode(int);
	private:
		node *head,*newNode,*ptr,*sav;
};
DoubleLinkedList::DoubleLinkedList(){
	head=NULL;
}
node *DoubleLinkedList::createNode(int value){
	newNode=new struct node;
	newNode->data=value;
	if(newNode==NULL){
		cout<<"Node is NULL has NOTHING on it.";
	}
	newNode->next=NULL;
	cout<<"New Node Created with value "<<newNode->data<<endl;
	return newNode;
}
int counter=0;
int main(){
	DoubleLinkedList s;
	int c,pos;
	s.Insert(0);
	while(1){
		s.options();
		cin>>c;
		switch(c){
			case 1:
				s.Insert(0);
				break;
			case 2:
				s.Insert(counter);
				break;
			case 3:
				cout<<"Enter Position to Insert the Element(1-"<<counter<<"):";
				cin>>pos;
				s.Insert(pos);
				break;
			case 4:
				s.Delete(0);
				break;
			case 5:
				s.Delete(counter);
				break;
			case 6:
				cout<<"Enter Position to Delete the Element(1-"<<counter<<"):";
				cin>>pos;
				s.Delete(pos);
				break;
			case 7:
			  s.Display();
			  break;
			case 8:
				s.Reverse();
				break;
			case 9:
				return 1;
				break;
			default:
				cout<<"Re-Enter the Choice.";
		}
	}
	return 0;
}
void DoubleLinkedList::Insert(int pos){
	int value;
	cout<<"Enter Value to Insert:";
	cin>>value;
	newNode=createNode(value);
	if(head==NULL){
		head=newNode;
	}
	else if(pos==0){
		newNode->pre=NULL;
		newNode->next=head;
		head->pre=newNode;
		head=newNode;
	}
	else if(pos==counter){
		ptr=head;
		while(ptr->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=newNode;
      	newNode->pre=ptr;
	}
	else if(pos>counter){
		cout<<"Unable to Insert at given Range.Placing at End.\n";
		ptr=head;
		while(ptr->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=newNode;
    	newNode->pre=ptr;
	}
	else{
		ptr=head;
		int i=1;
		while(i<pos-1){
			ptr=ptr->next;
			i++;
		}
		sav=ptr->next;
		newNode->next=sav;
		newNode->pre=ptr;
		sav->pre=newNode;
		ptr->next=newNode;
	}
	counter++;
	Display();
}
void DoubleLinkedList::Delete(int pos){
	if(head==NULL){
		cout<<"Insert and then Delete.\n";
	}
	else if(pos==0){
		ptr=head;sav=head;
		if(head->next!=NULL){
			head=ptr->next;
			head->pre=NULL;
		}
		else{
			head=NULL;
		}
		delete sav;
	}
	else if(pos==counter){
		ptr=head;
		while(ptr->next->next!=NULL){
			ptr=ptr->next;
		}
		sav=ptr->next;
		ptr->next=NULL;
		delete sav;
	}
	else if(pos>counter){
		cout<<"Unable to Delete at given Range.\n";
		counter++;
	}
	else{
		ptr=head;
		int i=0;
		while(i<pos-1){
			ptr=ptr->next;
			i++;
		}
		sav=ptr->next;
		ptr->next=sav->next;
		if(sav->next!=NULL){
			sav->next->pre=ptr;
		}
		delete sav;
	}
	counter--;
	Display();
}
void DoubleLinkedList::Reverse(){
	ptr=head;
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	cout<<"Elements are [END";
	while(ptr!=head){
		cout<<"<->"<<ptr->next<<"||"<<ptr->data<<"||"<<ptr->pre;
		ptr=ptr->pre;
	}
	cout<<"<->"<<ptr->next<<"||"<<ptr->data<<"||"<<ptr->pre;
	cout<<"<->HEAD]";
}
void DoubleLinkedList::Display(){
	ptr=head;
	cout<<"Elements are [HEAD";
	while(ptr!=NULL){
		cout<<"<->"<<ptr->pre<<"||"<<ptr->data<<"||"<<ptr->next;
		ptr=ptr->next;
	}
	cout<<"<->END]";
}
void DoubleLinkedList::options(){
	
	if(counter<1){
		cout<<"\nAvailable Options:-\n\t1.Insert\n\t4.Delete";
		cout<<"\n\t7.Display List\n\t9.EXIT\nEnter your Choice:";
	}
	else{
		cout<<"\nAvailable Options:-\n\t1.Insert at Front\n\t2.Insert at End\n\t3.Insert at a Position\n\t4.Delete at Front\n\t5.Delete at End\n\t6.Delete at a Position";
		cout<<"\n\t7.Display List\n\t8.Print in Reverse Order\n\t9.EXIT\nEnter your Choice:";
	}
}
