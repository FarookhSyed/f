#include<iostream.h>

template<class T>
void bubbleSort(T a[],int n){
	T temp;
	for(int i=0;i<n;i++){
		for(int j=0;j<n-1-i;j++){
			if(a[j]>a[j+1]){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
}
int main(){
	int n;
	cout<<"Enter the Range of the Elements:";
	cin>>n;
   int a[20];
	cout<<"Enter Elements:-\n";
	for(int i=0;i<n;i++)cin>>a[i];
	bubbleSort(a,n);
	cout<<"Sorted Order of Array:-\n";
	for(i=0;i<n;i++)cout<<a[i]<<" ";
	return 0;
}