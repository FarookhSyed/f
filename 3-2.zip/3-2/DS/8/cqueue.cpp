#include<iostream.h>
class CQueue{
	public:
		CQueue(int);
		void push(int);
		void pop();
		int &Rear();
		int &Front();
		int Isempty();
		int Isfull();
		void Display();
		void loop();
	private:
		int Qcapacity;
		int *Queue;
		int rear,front;
};
CQueue::CQueue(int capacity=10){
	Qcapacity=capacity;
	Queue=new int[Qcapacity];
	rear=0;
	front=Qcapacity;
	int x;
   for(x=0;x<Qcapacity;x++)Queue[x]=0;
	cout<<"Enter Element to Push:";
	cin>>x;
	push(x);
	front=0;
}
int &CQueue::Rear(){
	return Queue[rear];
}
int &CQueue::Front(){
	return Queue[front];
}
int CQueue::Isempty(){
	if(front==rear-1)return 1;
	return 0;
}
int CQueue::Isfull(){
	if(rear==Qcapacity)return 1;
	return 0;
}
void CQueue::loop(){
	 if(rear==Qcapacity && front>0){
			rear=0;
	 }
	 if(front==Qcapacity && rear>0){
			front=0;
	 }
}
void CQueue::Display(){
	int i=0;
	cout<<Queue[i];
	for(i=1;i<Qcapacity;i++){
		cout<<"->"<<Queue[i];
	}
}
int main(){
	int c,x;
	cout<<"Capacity of the Queue:";
	cin>>c;
	CQueue q(c);
	while(1){
		cout<<"\nAvailable Options:-\n\t1.Push\n\t2.Pop\n\t3.Front Element\n\t4.Rear Element\n\t5.Display Elements\nEnter Choice:";
		cin>>c;
		switch(c){
			case 1:
				cout<<"Enter the Value to Insert:";
				cin>>x;
				q.push(x);
				break;
			case 2:
				q.pop();
				break;
			case 3:
				cout<<"Front Element:"<<q.Front();
				break;
			case 4:
				cout<<"Rear Element:"<<q.Rear();
				break;
			case 5:
				q.Display();
				break;
			default:
				return 1;
		}
	}
	return a 0;
}
void CQueue::push(int item){
	if(!Isfull() && rear!=front){
		Queue[rear]=item;
		rear++;
	}else cout<<"Queue is FULL.";
	loop();
}
void CQueue::pop(){
	if(!Isempty() && front!=rear-1){
		Queue[front]=0;
		front++;
	}
	else cout<<"Queue is EMPTY.";
   loop();
}