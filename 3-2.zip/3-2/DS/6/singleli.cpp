#include<iostream.h>
struct node{
	int data;
	struct node *next;
};
int counter=0;
class singleLinkedList{
	public:
   		singleLinkedList();
		node *createNode(int);
		void insertNode(int);
		void deleteNode(int);
		void sort();
		void display();
		void options();
	private:
		struct node *head,*newNode,*ptr;
};
singleLinkedList::singleLinkedList(){
	head=NULL;
}
node *singleLinkedList::createNode(int value){
	newNode = new(struct node);
	if (newNode == NULL){
		cout<<"Memory not allocated"<<endl;
		return 0;
	}
	else{
		newNode->data = value;
		newNode->next = NULL;
		return newNode;
	}
}
int main(){
	singleLinkedList sl;
	int c,pos;
	while(1){
		sl.options();
		cin>>c;
		switch(c){
			case 1:
				sl.insertNode(1);
				break;
			case 2:
				sl.insertNode(counter);
				break;
			case 3:
				cout<<"Enter the Position of the Node to Insert(=<"<<counter<<"):";
				cin>>pos;
				sl.insertNode(pos);
				break;
			case 4:
				sl.deleteNode(1);
				break;
			case 5:
				sl.deleteNode(counter);
				break;
			case 6:
				cout<<"Enter the Position of the Node to Delete(=<"<<counter<<"):";
				cin>>pos;
				sl.deleteNode(pos);
				break;
			case 7:
				sl.sort();
				break;
			case 8:
				sl.display();
				break;
			case 9:
				exit(1);
				break;
			default:
				cout<<"Re-Enter 1-9\n";
				break;
		}
	}
   return 0;
}

void singleLinkedList::insertNode(int position){
	int value;
	cout<<"Enter the Value to Insert:";
	cin>>value;
	createNode(value);
	if(head==NULL){
		head=newNode;
	}
	else if(position==1){
		newNode->next=head;
		head=newNode;
	}
	else if(position==counter){
		ptr=head;
		while(ptr!=NULL){
			ptr=ptr->next;
		}
		ptr->next=newNode;
	}
	else{
		ptr=head;
		for(int i=1;i<position;i++){
			ptr=ptr->next;
		}
		ptr->next=newNode;
	}
	counter++;
}

void singleLinkedList::deleteNode(int position){
	ptr=newNode=head;
	if(head==NULL){
		cout<<"List is Empty. Please insert Someting to delete.\n";
	}
	else if(position==1){
		head=ptr->next;
	}
	else	if(counter==position){
		while(ptr->next->next!=NULL){
			ptr=ptr->next;
		}
		ptr->next=NULL;
	}
	else{
		for(int i=1;i<position;i++){
			ptr=ptr->next;
		}
		newNode=ptr->next->next;
		ptr->next=newNode;
	}
	counter--;
}
void singleLinkedList::display(){
	cout<<"LIST OF ELEMENTS:-\n";
	ptr=head;
	while(ptr!=NULL){
		cout<<ptr->data<<"\t";
		ptr=ptr->next;
	}
	cout<<endl;
}
void singleLinkedList::sort(){
	if(head==NULL){
		cout<<"List is Empty.\n";
	}
	else{
		int val;
		newNode=head;
		while(newNode!=NULL){
			for(ptr=newNode->next;ptr!=NULL;ptr=ptr->next){
				if((ptr->data)<(newNode->data)){
					val=ptr->data;
					ptr->data=newNode->data;
					newNode->data=val;
				}
			}
			newNode=newNode->next;	
		}
	}
}
void singleLinkedList::options(){
	if(head==NULL){
		cout<<"List is Empty.Starting at HEAD:-\n";
		insertNode(1);
	}
	if(counter<=2){
		cout<<"Single Linked List Available Options:-\n\t1.Insert at Front\n\t4.Delete at Front";
		cout<<"\n\t7.Sort List\n\t8.Display List\n\t9.EXIT\nEnter your Choice:";
	}
	else{
		cout<<"Single Linked List Available Options:-\n\t1.Insert at Front\n\t2.Insert at End\n\t3.Insert at a Position\n\t4.Delete at Front\n\t5.Delete at End\n\t6.Delete at a Position";
		cout<<"\n\t7.Sort List\n\t8.Display List\n\t9.EXIT\nEnter your Choice:";
	}
}

