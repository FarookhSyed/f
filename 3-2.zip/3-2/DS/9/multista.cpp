#include<iostream.h>
class multiStack{
	public:
		multiStack(int);
		int push(char);
		int pop(char);
		void Display();
	private:
		int capacity,TopA,TopB;
		int *Stack;
};
multiStack::multiStack(int c=10){
	capacity=c;
	Stack=new int[capacity];
	TopA=-1;
	TopB=capacity;
}
void multiStack::Display(){
	int i;
	if(TopA!=-1){
		cout<<"Stack[A]="<<Stack[0];
		for(i=1;i<=TopA;i++){
			cout<<"--"<<Stack[i];
		}
	}
	if(TopB!=capacity){
		cout<<"\nStack[B]="<<Stack[capacity-1];
			for(i=capacity-2;i>=TopB;i--){
				cout<<"--"<<Stack[i];
		}
	}
}
int main(){
	cout<<"Enter Capacity:";
	int c;
	cin>>c;
	multiStack s(c);
	while(1){
		cout<<"\nMultiStack Options:-\n\t1.Insert on StackA\n\t2.Insert on StackB\n\t3.Delete on StackA\n\t4.Delete on StackB\n\t5.Display\n\t6.Exit\nEnter your Choice:";
		cin>>c;
		switch(c){
			case 1:
				s.push('A');
				break;
			case 2:
				s.push('B');
				break;
			case 3:
				s.pop('A');
				break;
			case 4:
				s.pop('B');
				break;
			case 5:
				s.Display();
				break;
			case 6:
				return 1;
			default:
				cout<<"Re-Enter....";
		}
	}
}
int multiStack::push(char p){
	cout<<"Enter the Value to Push:";
	int val;cin>>val;
	if(TopA==TopB-1){
		cout<<"Stack-OverFlow.";
		val=0;
	}
	else{
		if(p=='A'){
			Stack[++TopA]=val;
		}
		else if(p=='B'){
			Stack[--TopB]=val;
		}
	}
	return val;
}
int multiStack::pop(char p){
	int val;
	if(TopA!=-1 && p=='A'){
		val=Stack[TopA];
		TopA--;
	}
	else if(TopB!=capacity && p=='B'){
		val=Stack[TopB];
		TopB++;
	}
	else{
		if(p=='A') cout<<"StackA-UnderFlow.";
		else if(p=='B') cout<<"StackB-UnderFlow.";
		val=0;
	}
	return val;
}
