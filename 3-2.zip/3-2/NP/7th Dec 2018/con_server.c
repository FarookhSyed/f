#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

main(int argc,char *argv[]){
        if(argc < 2){
                printf("usage:%s PORT\n",argv[0]);
                return 0;
        }
        char read_buf[256],write_buf[256];
        bzero((char *)&read_buf,255);
        bzero((char *)&write_buf,255);
        int sockfd;
        if((sockfd = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP))<0){
                perror("ERROR:socket creation error\n");
                return 0;
        }

        struct sockaddr_in server_addr;
        bzero((char *)&server_addr,sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(atoi(argv[1]));
        server_addr.sin_addr.s_addr = INADDR_ANY;

        int binder;
        if((binder = bind(sockfd,(struct sockaddr *)&server_addr,sizeof(server_addr)))<0){
                perror("ERROR:binding error\n");
                return 0;
        }

        int listener;
        if((listener = listen(sockfd,10)<0)){
                perror("ERROR:cannot start listening\n");
                return 0;
        }
        printf("Server started and listening...\n");

        struct sockaddr_in client_addr;
        int clientlen = 0;
        bzero((char *)&client_addr,sizeof(client_addr));
        int sock_obj;
        while(1){
                clientlen = sizeof(client_addr);
                if((sock_obj = accept(sockfd,(struct sockaddr *)&client_addr,&clientlen))){
                        printf("%d: New client connected\n",getpid());
                        int pid = fork();
                        if(pid < 0){
                                perror("ERROR:Child process cannot be created\n");
                                return 0;
                        }
                        else if(pid == 0){
                                int r = read(sock_obj,read_buf,255);
                                if(r<0){
                                        perror("ERROR:unable to read");
                                        exit(1);
                                }
                                printf("%d: Client message %s",getpid(),read_buf);
                                int w = write(sock_obj,"GOT THE MESSAGE",17);
                                if(w<0){
                                        perror("ERROR:unable to write");
                                        exit(1);
                                }
                                printf("%d: Response sent\n",getpid());
                        }
                }
        }
}
