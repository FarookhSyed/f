#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<netinet/tcp.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<fcntl.h>
#include<arpa/inet.h>

int main(){
	int len,x;
	int sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd < 0){
		perror("ERROR SOCKET NOT CREATED");
		exit(0);
	}printf("SOCKET CREATED\n");

	int a;
	getsockopt(sockfd,IPPROTO_TCP,TCP_MAXSEG,&a,&len);
	printf("IPPROTO_TCP > TCP_MAXSEG -> %d\n",a);
	
	int b;
	getsockopt(sockfd,IPPROTO_TCP,TCP_NODELAY,&b,&len);
	printf("IPPROTO_TCP > TCP_NODELAY -> %d\n",b);

	int c;
	getsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE,&c,&len);
	printf("BEFORE : SOL_SOCKET > SO_KEEPALIVE -> %d\n",c);
	
	x = 1;
	len = sizeof(x);
	setsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE,&x,len);
	getsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE,&c,&len);
        printf("AFTER : SOL_SOCKET > SO_KEEPALIVE -> %d\n",c);
}
