#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<netdb.h>

main(int argc,char * argv[]){
	if(argc < 2){
		printf("USAGE: %s PORT",argv[0]);
		exit(0);
	}
	int sockfd = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sockfd < 0){
		perror("ERROR SOCKET NOT CREATED\n");
		exit(0);
	}printf("SOCKET CREATED\n");

	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(atoi(argv[1]));
	
	int connfd = connect(sockfd,(struct sockaddr *)&server,sizeof(server));
	
	if(connfd < 0){
		perror("CONNECTION CANNOT BE MADE\n");
		exit(0);
	}printf("CONNECTION SUCESSFUL\n\n");
	
	int len = sizeof(server);
	getpeername(sockfd,(struct sockaddr *)&server,&len);
	printf("HOST : %s\n",inet_ntoa(server.sin_addr));
	printf("PORT : %d\n",ntohs(server.sin_port));
}
