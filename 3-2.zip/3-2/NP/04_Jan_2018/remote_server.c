#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

main(int argc,char *argv[]){
	if(argc<2){
		printf("USAGE: %s PORT\n",argv[0]);
		return 0;
	}char buffer[1024];
	int sockfd = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(sockfd<0){
		perror("SOCKET NOT CREATED");
		exit(0);
	}printf("SOCKET CREATED\n");
	
	struct sockaddr_in server,client;
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(atoi(argv[1]));
	int t = bind(sockfd,(struct sockaddr *)&server,sizeof(server));
	if(t<0){
		perror("SERVER NOT BINDED");
		exit(0);
	}printf("BINDING SUCESSFUL\n");

	t = listen(sockfd,5);
	if(t<0){
		perror("SERVER CANNOT LISTEN");
		exit(0);
	}printf("SERVER LISTENING\n");
	int connection,len,fd;
	while(1){
		if((connection=accept(sockfd,(struct sockaddr *)&server,&len))<0){
			continue;
		}
	l:	bzero(buffer,sizeof(buffer));
		t = recv(connection,buffer,sizeof(buffer),0);

		if(t < 1){
			printf("PROBLEM WITH CONNECTION CLOSING\n");
			continue;
		}

		strcat(buffer,">command.txt");
		//printf("%s\n",buffer);
		system(buffer);

		fd = open("command.txt",O_RDONLY,0666);
		if(fd<1){
			printf("PROBLEM WITH FILE\n");
			continue;
		}
		read(fd,buffer,sizeof(buffer));
		
		t = send(connection,buffer,strlen(buffer),0);
		
		//printf("DATA SENT SUCESSFULLY\n");
		goto l;
	}
}
