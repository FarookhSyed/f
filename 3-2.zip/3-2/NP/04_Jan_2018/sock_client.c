#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<netdb.h>

int main(int argc,char *argv[1]){
	int portno,sockfd;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buf[1024];
	if(argc < 3){
		printf("Please provide the host name and  port number.\n");
		return 0;
	}
	printf("host: %s , port: %s is the server\n",argv[1],argv[2]);
	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0){
		perror("ERROR:socket not created");
		exit(1);
	}
	printf("Socket created\n");
	
	server = gethostbyname(argv[1]);
	if(!server){
		perror("ERROR:server not found");
		exit(1);
	}
	printf("Server recognised\n");
	
	bzero((char *) &serv_addr,sizeof(serv_addr));

	bcopy((char *)server->h_addr,(char *)&serv_addr.sin_addr.s_addr,server->h_length);
	portno = atoi(argv[2]);
	serv_addr.sin_port = htons(portno);
	serv_addr.sin_family = AF_INET;

	if(connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))<0){
		perror("ERROR:connection cannot be made.\n");
		exit(1);
	}
	system("clear");
	while(1){
		bzero(buf,1024);

		printf("$ ");
		//fgets(buf,1024,stdin);
		//buf[strlen(buf)]="";
		scanf("%s",&buf);
		//printf("%s",buf); 
		if(strcmp((const char *)&buf,"exit")==0){
			close(sockfd);
			break;
		}
		//printf("Sending %s\n",buf);	
		write(sockfd,buf,strlen(buf));
	
		bzero(buf,sizeof(buf));

		recv(sockfd,buf,sizeof(buf),0);
	
		printf("%s",buf);
	}
	return 1;

	
}
