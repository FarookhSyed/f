import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;

class MailSender{
	
	public boolean consoleInput(){
		Scanner in = new Scanner(System.in);
		System.out.print("From : ");
		String from = in.nextLine();
		System.out.print("Password : ");
		String password = in.nextLine();
		System.out.print("To : ");
		String to = in.nextLine();
		System.out.print("Subject : ");
		String subject = in.nextLine();
		System.out.println("Message (use 'EOF' to end):- ");
		String message = "";
		String x = in.nextLine();
		while(x.compareTo("EOF")!=0){
			message += "\n" + x;
			x = in.nextLine();
		}
		
		return authMail(from,to,password,subject,message);
	}
	
	public boolean authMail(
		final String from,
		final String to,
		final String password,
		final String subject,
		final String message)
	{
		
		System.out.println("Processing Mail...");

		Properties prop = new Properties();
		prop.put("mail.smtp.host","smtp.gmail.com");
		prop.put("mail.smtp.auth",true);
		prop.put("mail.smtp.starttls.enable",true);
		prop.put("mail.smtp.port","587");
		
		Session session = Session.getDefaultInstance(prop,
			new javax.mail.Authenticator(){
				protected PasswordAuthentication getPasswordAuthentication(){
					return new PasswordAuthentication(from,password);
				}
			}
		);
		
	try{
		
			MimeMessage format = new MimeMessage(session);
			format.setFrom(new InternetAddress(from));
			format.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
			format.setSubject(subject);
			format.setText(message);

			System.out.println("Ready to send the mail");
			
			Transport.send(format);
			System.out.println("Sent...");
		}
		catch(Exception e){
			System.out.println("Failed...");
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public static void main(String args[]){
		String from = "abcd@gmail.com";
		if(new MailSender().consoleInput())
		//if(new MailSender().authMail(from,"gopinadh5g7@sasi.ac.in","dont ask","smtp example","hello !!!"))
			System.out.println("Mail Sent...");
		else
			System.out.println("Failed!!!");
	}
	
}