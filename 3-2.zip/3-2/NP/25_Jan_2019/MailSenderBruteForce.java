import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;

class MailSenderBruteForce{
	static String subject = "This is important you bitch - ";
	static long count = 0;
	static Session session = null;
	static Properties prop = null;
	public boolean sendMail(
		final String from,
		final String to,
		final String subject,
		final String message){
		try{
		
			MimeMessage format = new MimeMessage(session);
			format.setFrom(new InternetAddress(from));
			format.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
			format.setSubject(subject + count);
			format.setText(message);
			
			Transport.send(format);
			System.out.println("Sent...");
		}
		catch(Exception e){
			System.out.println("Failed...");
			e.printStackTrace();
			return false;
		}
		
		return true;
		
	}
	
	public static void authMail(
		final String from,
		final String password)
	{

		prop = new Properties();
		prop.put("mail.smtp.host","smtp.gmail.com");
		prop.put("mail.smtp.auth",true);
		prop.put("mail.smtp.starttls.enable",true);
		prop.put("mail.smtp.port","587");
		
		try{
			session = Session.getDefaultInstance(prop,
				new javax.mail.Authenticator(){
					protected PasswordAuthentication getPasswordAuthentication(){
						return new PasswordAuthentication(from,password);
					}
				}
			);
		
			System.out.println("Login Successful");
		}catch(Exception e){
			System.out.println("Login Failed");
			authMail(from,password);
		}
		
		if(session == null)
			authMail(from,password);
	
	}
	static String from = "gopinadh5g7@sasi.ac.in";
	static String password = "Don't ask me please";
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		from = in.nextLine();
		password = in.nextLine();
		authMail(from,password);
		System.out.println("Ready to send the mail");
		while(true){
			try{
				ThreadRipper tr = new ThreadRipper();
				tr.start();
				Thread.sleep(3000);
			}catch(Exception e){}
			break;
		}
	}
	
	static class ThreadRipper extends Thread{
	
		public void run(){
			
			try{
				while(true){
					if(new MailSenderBruteForce().sendMail(from,"neeraj5d5@sasi.ac.in",subject,"Hi Cyberboy this isn't going good for you now!!!"))
						System.out.println("Mail Sent...1");
					else
						System.out.println("Failed!!!1");
					this.sleep(500);
					if(new MailSenderBruteForce().sendMail(from,"yesupadam5g3@sasi.ac.in ",subject,"Hi Cyberboy this isn't going good for you now!!!"))
						System.out.println("Mail Sent...2");
					else
						System.out.println("Failed!!!2");
					this.sleep(1000);
					count += 1;
				}
			}catch(Exception e){
				try{
					this.sleep(1000);
					ThreadRipper tr = new ThreadRipper();
					tr.start();
				}
				catch(Exception ef){}
			}
		}
	
	}
	
	
	
}