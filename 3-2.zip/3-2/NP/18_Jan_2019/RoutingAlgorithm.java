import java.util.*;

public class RoutingAlgorithm{
	int size,routes[][],path[][];
	Scanner in;

	RoutingAlgorithm(){
		this.in = new Scanner(System.in);

		System.out.print("Enter no.of Nodes in the Route: ");
		this.size = this.in.nextInt();
		
		this.routes = new int[this.size][this.size];
		this.path = new int[this.size][this.size];
		System.out.println("Enter Adjacency Matrix:- ");
		for(int i=0;i<this.size;i++){
			for(int j=0;j<this.size;j++){
				this.routes[i][j] = this.in.nextInt();
				if(this.routes[i][j] == 0)
					this.routes[i][j] = Integer.MAX_VALUE;
				this.path[i][j] = 0;
			}
		}
	}

	public void applyKrushkal(){
		boolean visited[] = new boolean[this.size];
		for(int i=0;i<this.size;i++)
			visited[i] = false;

		int mat[][] = new int[this.size][this.size];
		for(int i=0;i<this.size;i++){
			for(int j=0;j<this.size;j++){
				mat[i][j] = this.routes[i][j];
			}
		}

		int n = 0,low,u,v;
		while(n < this.size-1){
			low = Integer.MAX_VALUE;
			u = -1;v = -1;
			for(int i=0;i<this.size;i++){
				for(int j=0;j<this.size;j++){
					if(i == j)
						continue;
					if(visited[i] && visited[j]){
						int count = 0;
						for(int k=0;k<visited.length;k++){
							if(visited[k])
								count++;
						}
						if(count != visited.length)
							continue;
					}
					if(mat[i][j] < low){
						low = mat[i][j];
						u = i;
						v = j;
					}
				}
			}
			if(v == -1 || u == -1)
				break;
			mat[u][v] = Integer.MAX_VALUE;
			mat[v][u] = Integer.MAX_VALUE;
			path[u][v] = 1;
			path[v][u] = 1;
			visited[u] = true;
			visited[v] = true;
			n += 1;
		}

	}
	
	public int connectedNode(int s,int d,int mat[][],boolean visited[]){
		int count = 0;
		for(int i=0;i<visited.length;i++){
			if(visited[i])
				count++;
		}
		if(count == visited.length-1)
			return 1;
		else
			return 0;
	}

	public int distance(int [][]mat,int s,int d){
		int dist = 0;
		int low = Integer.MAX_VALUE;
		int u = -1;
		for(int i=0;i<this.size;i++){
			if(mat[s][d] != 0){
				dist = mat[s][d];
				break;
			}
			if(i == s)
				continue;
			if(mat[s][i] < low && mat[s][i] != 0)
				u = i;
		}

		if(u != -1){
			dist += distance(mat,s,u);
			dist += distance(mat,u,d);
			// System.out.print(u);
		}
		
		return dist;
	}

	public int[][] algorithm(){
		this.applyKrushkal();

		int mat[][] = new int[this.size][this.size];
		System.out.println("\nShortest Path :- ");
		for(int i=0;i<this.size;i++){
			for(int j=0;j<this.size;j++){
				if(path[i][j] != 1){
					mat[i][j] = 0;
					System.out.print("0\t");
				}
				else{
					mat[i][j] = routes[i][j];
					System.out.print(routes[i][j]+"\t");
				}
			}
			System.out.println();
		}System.out.println();

		for(int i=0;i<this.size;i++){
			for(int j=0;j<this.size;j++){
				if(i == j)
					continue;
				if(mat[i][j] == 0){
					mat[i][j] = distance(mat,i,j);
					mat[j][i] = mat[i][j];
				}
			}	
		}
		System.out.println("\nShortest Routing Vector :- ");
		printMatrix(mat);
		return mat;
	}

	public static void printMatrix(int [][]mat){
		for(int i=0;i<mat.length;i++){
			for(int j=0;j<mat[i].length;j++){
				if(mat[i][j] == Integer.MAX_VALUE)
					System.out.print("0\t");
				else
					System.out.print(mat[i][j]+"\t");
			}
			System.out.println();
		}
	}

	public static void main(String args[]){
		RoutingAlgorithm ra = new RoutingAlgorithm();
		// ra.printMatrix(ra.routes);
		ra.algorithm();

	}

}