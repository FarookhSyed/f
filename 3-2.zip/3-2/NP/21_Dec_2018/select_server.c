#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/select.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

#define MAX_SIZE 1025

int main(int argc,char *argv[]){
	char buffer[MAX_SIZE];
	if(argc < 2){
		printf("Usage : %s PORT",argv[0]);
		return 0;
	}
	int sockfd;
	if((sockfd = socket(AF_INET,SOCK_STREAM,0))<0){
		printf("ERROR: SOCKET NOT CREATED\n");
		exit(0);
	}printf("SOCKET CREATED\n");

	struct sockaddr_in server;
	bzero((char *)&server,sizeof(server));
	server.sin_port = htons(atoi(argv[1]));
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_family = AF_INET;

	if((bind(sockfd,(struct sockaddr *)&server,sizeof(server)))<0){
		printf("ERROR: UNABLE TO BIND");
		exit(1);
	}printf("BINDING SUCESSFULL\n");
		
	int listenfd = sockfd;
	listen(sockfd,5);

	int i,j,client[FD_SETSIZE],nread,connfd,clientlen,maxi;
	size_t n;
	fd_set rset,allset;
	int maxfd = listenfd;
	maxi = -1;
	for(i=0;i<FD_SETSIZE;i++){
		client[i] = -1;
	}
	FD_ZERO(&allset);
	FD_SET(listenfd,&allset);
	struct sockaddr_in clientaddr;
	printf("SERVER LISTENING\n");
	while(1){
		rset = allset;
		nread = select(maxfd+1,&rset,NULL,NULL,NULL);
		//printf("nread = %d\n",nread);
		if(FD_ISSET(listenfd,&rset)){
			clientlen = sizeof(clientaddr);
			connfd = accept(listenfd,(struct sockaddr *)&clientaddr,&clientlen);
			printf("NEW CLIENT CONNECTED\n");
			for(i=0;i<FD_SETSIZE;i++)
				if(client[i]<0){
					client[i] = connfd;
					//printf("connfd = %d\n",client[i]);
					break;
				}
				if(i == FD_SETSIZE-1){
					printf("MANY CLIENTS");
					exit(0);
				}
				FD_SET(connfd,&allset);
				if(connfd > maxfd)
					maxfd = connfd;
				if(i  > maxi)
					maxi = i;
				if(--nread <= 0)
					continue;
		}//printf("out of loop-1\n");
		//printf("maxi = %d\n",maxi);
		for(i=0;i<=maxi;i++){
			//printf("IN LOOP\n");
			if((sockfd=client[i]) < 0)
				continue;
			if(FD_ISSET(sockfd,&rset)){
				bzero((char *)buffer,sizeof(buffer));
				printf("WAITING FOR INPUT FROM CLIENT\n");
				if((n = read(sockfd,buffer,MAX_SIZE))<=0){
					close(sockfd);
					FD_CLR(sockfd,&allset);
					client[i] = -1;
				}else{
					//printf("%d\n",strlen(buffer));		
					//printf("%s",buffer);
					for(j=0;buffer[j] != '\0';j++){
						buffer[j] = toupper(buffer[j]);
					}printf("SENDING THE OUTPUT\n");
					write(sockfd,buffer,strlen(buffer));
				}
			}
			//printf("nread = %d\n",nread);	
			if(--nread <= 0)
				break;
		}//printf("out of loop-2\n");
		
	}
}
