#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

#define MAX 1025

int main(int argc,char *argv[]){
        char buffer[MAX-1];

        if(argc < 2){
                printf("USAGE: %s PORT\n",argv[0]);
                exit(1);
        }

        int sockfd;
        if((sockfd=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP))<0){
                perror("ERROR:Unable to create socket\n");
                exit(1);
        }
        printf("Socket created\n");

        struct sockaddr_in server;
        memset(&server,0,sizeof(server));
        server.sin_addr.s_addr = INADDR_ANY;
        server.sin_port = htons(atoi(argv[1]));
        server.sin_family = AF_INET;
        printf("Requesting the Time...\n");
        //fgets(buffer,MAX-1,stdin);
        int bytes,serverlen;
        strcpy(buffer,"TIME PLEASE...");
        bytes = sendto(sockfd,(const char *)buffer,strlen(buffer),0,(const struct sockaddr *)&server,sizeof(server));

        if(bytes<0){
                perror("ERROR:Transaction error occurred\n");
                exit(1);
        }

        //printf("Message Sent\n");

        bytes = recvfrom(sockfd,(char *)buffer,MAX,0,(struct sockaddr *)&server,&serverlen);

        if(bytes<0){
                perror("ERROR:Transaction error occurred\n");
                exit(1);
        }
        else{
                buffer[bytes] = '\0';
                printf("Time : %s\n",buffer);
        }

}
