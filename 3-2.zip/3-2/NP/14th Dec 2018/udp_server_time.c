#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<time.h>

#define MAX 1025

int main(int argc,char *argv[]){
        char buffer[MAX-1];
        time_t now;
        struct tm *timeinfo;
        char timestring[9];
        if(argc < 2){
                printf("USAGE: %s PORT\n",argv[0]);
                exit(1);
        }

        int sockfd;
        if((sockfd=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP))<0){
                perror("ERROR:Unable to create socket\n");
                exit(1);
        }
        printf("Socket created\n");

        struct sockaddr_in server,client;
        memset(&server,0,sizeof(server));
        memset(&client,0,sizeof(client));
        server.sin_family = AF_INET;
        server.sin_addr.s_addr = INADDR_ANY;
        server.sin_port = htons(atoi(argv[1]));

        int binder;
        if((binder=bind(sockfd,(struct sockaddr *)&server,sizeof(server)))<0){
                perror("ERROR:Unable to bind the port\n");
                exit(1);
        }
        printf("Socket binded\n");

        int clientlen,bytes;

        bytes = recvfrom(sockfd,(char *)buffer,MAX,0,(struct sockaddr *)&client,&clientlen);

        if(bytes<0){
                perror("ERROR:Transaction error occurred\n");
                exit(1);
        buffer[bytes] = '\0';
        printf("Request is \'%s\'\n",buffer);
        time(&now);
        timeinfo = localtime(&now);
        strftime(&timestring,sizeof(timestring),"%H:%M:%S",timeinfo);
        printf("Time : %s\n",timestring);

        bytes = sendto(sockfd,(const char *)timestring,strlen(timestring),0,(const struct sockaddr *)&client,sizeof(client));

        if(bytes<0){
                perror("ERROR:Transaction error occurred\n");
                exit(1);
        }

        //printf("Message Sent\n");
        return 1;
}
