import java.util.Scanner;
import java.net.Socket;

class FTPServer{

	public static class FileRecv extends Thread{
		private Socket connection;
		FileRecv(Socket connection){
			this.connection = connection;
		}
		public void run(){
			try{
                FTP.recvFile(this.connection,FTP.getFilename(this.connection));
            }catch(Exception e){
				System.out.println("File Transfer failed");
			}
		}
	}

    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        FTP server = new FTP();

        System.out.print("Binding Port: ");
        int port = in.nextInt();
        
        try{
            server.bind(port);
        }catch(Exception e){
            System.out.println("Server can't be created");
            return;
        }

        System.out.println("Listening Started...");

		Socket connection = null;
		while(true){
			connection = server.accept();

			if(connection != null){
				new FileRecv(connection).start();			
			}

			connection = null;
		}
    }
}