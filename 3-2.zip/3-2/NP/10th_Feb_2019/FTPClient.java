import java.util.Scanner;

class FTPClient{
    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        FTP client = new FTP();

        System.out.print("Filename : ");
        String filename = in.nextLine();

        System.out.print("Hostname : ");
        String hostname = in.nextLine();

        System.out.print("Port : ");
        int port = in.nextInt();
        
        try{
            client.connect(hostname,port);
            client.sendFilename(filename);
        }catch(Exception e){
            System.out.println("Server can't be contacted");
            return;
        }
        
        try{
            client.sendFile(filename);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("File Transfer failed");
        }
    }
}