import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;

class FTP{

    private ServerSocket server;
    private Socket client;
    public void sendFile(String filename)throws IOException{
        System.out.println("Transaction Started");

        DataOutputStream dos = new DataOutputStream(client.getOutputStream());
        FileInputStream fis = new FileInputStream(filename);
        byte[] buffer = new byte[1024*1024];

        while(fis.read(buffer)>0){
            dos.write(buffer);
        }

        dos.close();
        fis.close();
        
        System.out.println("File sent sucessfully");
    }
    public static void recvFile(Socket connection,String filename)throws IOException{
        System.out.println("Transaction Started");

        DataInputStream dis = new DataInputStream(connection.getInputStream());
        FileOutputStream fos = new FileOutputStream("FTP/"+filename);

        byte[] buffer = new byte[1024*1024];
        int read = 0;
        while((read = dis.read(buffer,0,buffer.length))>0){
            fos.write(buffer,0,read);
        }

        dis.close();
        fos.close();

        System.out.println("File received sucessfully");
    }
    public static String getFilename(Socket connection)throws IOException{
        DataInputStream dis = new DataInputStream(connection.getInputStream());
        String filename = "";
        filename = dis.readUTF();
        return filename;
    }
    public void sendFilename(String filename)throws IOException{
        DataOutputStream dos = new DataOutputStream(client.getOutputStream());
        dos.writeUTF(filename);
		dos.flush();
    }
    public void connect(String host,int port){
        try{
            client = new Socket(host,port);
        }catch(Exception e){}
    }

    public void bind(int port){
        try{
            server = new ServerSocket(port);
        }catch(Exception e){}
    }

    public Socket accept(){
        Socket connection = null;
        try{
            connection = server.accept();
            System.out.println("New Client Connected");
        }catch(Exception e){}

        return connection;
    }


}