
class RSA{
    private int p,q;
    private int n,e,d,pie_n;

    public int min = 0,max = 128;
    public RSA(int p,int q){
        this.p = p;
        this.q = q;
        this.e = e;
        
        this.n = p * q;
        this.pie_n = (p-1) * (q-1);
    } 
    public RSA(){
        this.p = this.getPrime();
        this.q = this.p;
        while(this.q == this.p)
            this.q = this.getPrime();

        
    }

    public int getPrime(){
        int n = (int)((Math.random() * ( max - min )) + min);
        if(n < 2)
            return getPrime();
        if(n == 2)
            return n;
        for(int i=2;i<n;i++){
            if(n%i == 0)
                return getPrime();
        }
        return n;
    }
    public int getGCD(int a,int b){
        int n = 1;
        for(int i=2;i<=a && i<=b;i++)
            if(a%i == 0 && b%i == 0)
                n = i;
        return n;
    }

    public int getEValue(int pie_n){
        int n = (int)((Math.random() * ( max - min )) + min);
        if(n < 1 || n > this.n || getGCD(pie_n,n) != 1)
            return getEValue(pie_n);
        return n;
    }

    public void generateKeys(int e){
        this.n = p * q;
        this.e = e;
        int pie_n = (p-1) * (q-1);

        for(int i=0;i<=pie_n;i++){
            int x = i*e;
            if(x % pie_n == 1){
                this.d = i;
                break;
            }
        }
    }

    public void generateKeys(){
        this.n = p * q;

        int pie_n = (p-1) * (q-1);

        this.e = this.getEValue(pie_n);

        for(int i=0;i<=pie_n;i++){
            int x = i*e;
            if(x % pie_n == 1){
                this.d = i;
                break;
            }
        }
    }

    public int[] getPublicKey(){
        int []PU = {e,n};
        return PU;
    }

    public int[] getPrivateKey(){
        int []PR = {d,n};
        return PR;
    }

}