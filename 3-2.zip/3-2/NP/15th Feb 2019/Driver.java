import java.net.*;
import java.util.*;

class Driver{

    public static void main(String args[]){
        Scanner in = new Scanner(System.in);

        RSA encrypt = new RSA(3,11);
        
        encrypt.generateKeys(7);
        
        System.out.println(encrypt.getPublicKey()[0]);
                
        System.out.println(encrypt.getPrivateKey()[0]);

        while(true){
            System.out.print("Text: ");
            long m = in.nextLong();
            long encrypted = (long) Math.pow(m,encrypt.getPublicKey()[0]) % encrypt.getPublicKey()[1];
            System.out.println("Encrypted: "+encrypted);
            long decrypted = (long) Math.pow(encrypted,encrypt.getPrivateKey()[0]) % encrypt.getPrivateKey()[1];
            System.out.println("Decrypted: "+decrypted);
        }
        
    }

}