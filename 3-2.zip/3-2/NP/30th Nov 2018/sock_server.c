#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>

int main(int argc,char *argv[]){
        char buf[256];
        if(argc < 2){
                printf("Please provide the port number.\n");
                return 0;
        }
        else{
                printf("Starting on port : %s\n",argv[1]);
        }
        int sockfd = socket(AF_INET,SOCK_STREAM,0);
        if(sockfd<0){
                perror("ERROR:socket not create");
                exit(1);
        }
        printf("Socket started\n");
        struct sockaddr_in server_addr;
        bzero((char *) &server_addr,sizeof(server_addr));

        server_addr.sin_port = htons(atoi(argv[1]));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;

        if(bind(sockfd,(struct sockaddr *) &server_addr,sizeof(server_addr))<0){
                perror("ERROR:binding cannot be made.\n");
                exit(1);
        }

        listen(sockfd,4);

        int socket_obj;
        struct sockaddr_in client_addr;
        int clientlen = sizeof(client_addr);
        if((socket_obj = accept(sockfd,(struct sockaddr *) &client_addr,&clientlen))<0){
                perror("ERROR:cannot accept any clients.\n");
                exit(1);
        }
        printf("New client connected\n");

        bzero(buf,256);

        int e = read(socket_obj,buf,255);
        if (e<0){
                perror("ERROR:problem with reading\n");
        }
        printf("Message :- \n %s",buf);

        write(socket_obj,"\nGOT THE MESSAGE\n",19);

        return 1;


}
