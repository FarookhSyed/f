// https://opentdb.com/api_config.php
// https://opentdb.com/api.php?amount=20&category=15&difficulty=hard&type=multiple
const mcq = { "response_code": 0, "results": [{ "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "What was the code name given to Sonic the Hedgehog 4 during its development?", "correct_answer": "Project Needlemouse", "incorrect_answers": ["Project Bluespike", "Project Roboegg", "Project Darksphere"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "What is the name of the virus that infected New York in Tom Clancy&#039;s The Division?", "correct_answer": "Dollar Flu", "incorrect_answers": ["Ebola", "Red Poison", "Smallpox"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "The Internet Meme &quot;All your base are belong to us&quot; is based on the poorly translated English Version of which Video Game?", "correct_answer": "Zero Wing", "incorrect_answers": ["F-Zero", "Wing Commander", "Star Wars: X-Wing"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "The map featured in Arma 3 named &quot;Altis&quot; is based off of what Greek island?", "correct_answer": "Lemnos", "incorrect_answers": ["Ithaca", "Naxos", "Anafi"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In the Gamecube Version of &quot;Resident Evil&quot; what text document is open on the monitor of the computer in the Visual Data Room?", "correct_answer": "A GDC Document", "incorrect_answers": ["Text Document on Herbs", "Nothing", "Document on B.O.Ws"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In &quot;Sonic the Hedgehog 3&quot; for the Sega Genesis, what is the color of the second Chaos Emerald you can get from Special Stages?", "correct_answer": "Orange", "incorrect_answers": ["Blue", "Green", "Magenta"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "When was Steam first released?", "correct_answer": "2003", "incorrect_answers": ["2004", "2011", "2007"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "How long are all the cutscenes from Metal Gear Solid 4 (PS3, 2008) combined?", "correct_answer": "8 hours", "incorrect_answers": ["4 hours", "12 hours", "5 hours"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "Which of these Pok&eacute;mon cannot learn Surf?", "correct_answer": "Arbok", "incorrect_answers": ["Linoone", "Tauros", "Nidoking"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In the title of the game &quot;Luigi&#039;s Mansion&quot;, what is the only letter to not appear with a pair of eyes in it?", "correct_answer": "s", "incorrect_answers": ["n", "i", "m"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "The creeper in Minecraft was the result of a bug while implementing which creature?", "correct_answer": "Pig", "incorrect_answers": ["Zombie", "Chicken", "Cow"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "How many trophies are there in &quot;Super Smash Bros. for Nintendo 3DS&quot;?", "correct_answer": "685", "incorrect_answers": ["1360", "716", "1155"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "How many voice channels does the Super Nintendo Entertainment System support?", "correct_answer": "8", "incorrect_answers": ["6", "10", "12"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "How many aces can be shot down through the entirety of &quot;Ace Combat Zero: The Belkan War&quot;?", "correct_answer": "169", "incorrect_answers": ["100", "132", "245"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "Which game in the &quot;Monster Hunter&quot; series introduced the &quot;Insect Glaive&quot; weapon?", "correct_answer": "Monster Hunter 4", "incorrect_answers": ["Monster Hunter Freedom", "Monster Hunter Stories", "Monster Hunter 2"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In the &quot;PAYDAY&quot; series, what is the real name of the character known as &quot;Dallas&quot;?", "correct_answer": "Nathan Steele", "incorrect_answers": ["Nate Siemens", "Nick Stamos", "Nolan Stuhlinger"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "What was the first &quot;Call Of Duty: Zombies&quot; map to be directed by Jason Blundell?", "correct_answer": "Mob Of The Dead", "incorrect_answers": ["Buried", "Origins", "Moon"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In the &quot;Call Of Duty: Zombies&quot; map &quot;Origins&quot;, where is &quot;Stamin-Up&quot; located?", "correct_answer": "Generator 5", "incorrect_answers": ["Generator 3", "Generator 4", "Excavation Site"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In &quot;Team Fortress 2&quot;, what is the fastest taunt kill that can be pulled off?", "correct_answer": "Showdown", "incorrect_answers": ["Hadouken", "Organ Grinder", "Skewer"] }, { "category": "Entertainment: Video Games", "type": "multiple", "difficulty": "hard", "question": "In Diablo lore, this lesser evil spawned from one of the seven heads of Tathamet, and was known as the Maiden of Anguish.", "correct_answer": "Andariel", "incorrect_answers": ["Valla", "Malthael", "Kashya"] }] }

const maintag = document.createElement('mcqs')
for (let i in mcq.results) {
    const q = mcq.results[i]
    const m = document.createElement('mcq')
    const question = document.createElement('question')
    let value = document.createElement('value')
    value.innerHTML = q.question
    question.append(value)
    m.append(question)

    const category = document.createElement('category')
    value = document.createElement('value')
    value.innerHTML = q.category
    category.append(value)
    m.append(category)

    const options = document.createElement('options')

    for (j in q.incorrect_answers) {
        const option = document.createElement('option')
        value = document.createElement('value')
        value.innerHTML = q.incorrect_answers[j]
        option.append(value)
        options.append(option)
    }

    const option = document.createElement('option')
    value = document.createElement('value')
    value.innerHTML = q.correct_answer
    option.append(value)
    options.append(option)
    m.append(options)

    const solution = document.createElement('solution')
    value = document.createElement('value')
    value.innerHTML = q.correct_answer
    solution.append(value)
    m.append(solution)

    maintag.append(m)
}
document.body.append(maintag)