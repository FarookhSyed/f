<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://gopinadh5g7.000webhostapp.com/componentStyle.css"/>
    <title>LOGIN</title>
</head>
<body>
<?php
    $FAILED = FALSE;
    if(isset($_POST["username"])){
        $username = $_POST["username"];
        $password = $_POST["password"];

        $connection = new mysqli("localhost","id6290457_gopinadh5g7","9874NESF","id6290457_gopinadh5g7");

        $result = $connection->query("select * from users where id='$username'");
        if($result)
            if($result->num_rows === 0){
                echo "Incorrect username or password";
                $FAILED = TRUE;
            }else{
               while($row = $result->fetch_assoc()){
                   if($row["id"] === $username){
                        if(md5($row["password"]) === md5($password)){
                            echo "LOGIN SUCCESSFUL";
                        }
                        else{
                            echo "Incorrect username or password";
                            $FAILED = TRUE;
                        }
                        break;
                    }
               }
               

            }
    }else
        $FAILED = TRUE;
    if($FAILED){
?>
    <form class="container box" action="#" method="POST" onSubmit="return validate()">
        <div class="row">
            <label>Username:</label>
            <input class="input-box" type="text" name="username" placeholder="developerswork"/>
        </div>
        <div class="row">
            <label>Password :</label>
            <input class="input-box" type="password" name="password" placeholder="********"/>
        </div>
        <div class="row">
            <button class="btn" type="submit">LOGIN</button>
            <button class="btn" type="reset">RESET</button>
        </div>
    </form>
<?php
    }
?>
</body>
</html>