<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://gopinadh5g7.000webhostapp.com/componentStyle.css"/>
        <title>MYSQL DB</title>
    </head>
    <body>
        <table width="100%">
        <?php 
            $connection = new mysqli("localhost","id6290457_gopinadh5g7","9874NESF","id6290457_gopinadh5g7");

            $result = $connection->query("select * from users;");

            if($result){
                if($result->num_rows > 0){
                    ?>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>EMAIL</th>
                        <th>MOBILE</th>
                        <th>CREATED ON</th>
                    </tr>
                    <?php
                    while($row = $result->fetch_assoc()){
                        echo "<tr>";
                        echo "<td>".$row['id']."</td>";
                        echo "<td>".$row['name']."</td>";
                        echo "<td>".$row['email']."</td>";
                        echo "<td>".$row['mobile']."</td>";
                        echo "<td>".$row['timestamp']."</td>";
                        echo "</tr>";
                    }
                }else{
                    echo "EMPTY DATA";
                }
            }
        
        ?>
        </table>
    </body>
</html>