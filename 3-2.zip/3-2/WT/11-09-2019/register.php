<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://gopinadh5g7.000webhostapp.com/componentStyle.css"/>
    <title>REGISTRATION</title>
</head>
<body>
<?php
    $FAILED = FALSE;
    if(isset($_POST["username"])){
        $username = $_POST["username"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $mobile = $_POST["mobile"];
        $password = $_POST["password"];

        $connection = new mysqli("localhost","id6290457_gopinadh5g7","9874NESF","id6290457_gopinadh5g7");

        $result = $connection->query("select * from users where id='$username'");
        if($result)
            if($result->num_rows > 0){
                echo "$username, already exists. Try something else....";
                $FAILED = TRUE;
            }else{
                $query = "INSERT INTO users(`id`, `name`, `password`, `email`, `mobile`) VALUES('$username','$name','$password','$email','$mobile')";
                if($connection->query($query)){
                    echo "REGISTRATION SUCESSFUL";
                }else{
                    echo "REGISTRATION FAILED";
                }

            }
    }else
        $FAILED = TRUE;
    if($FAILED){
?>
    <form class="container box" action="#" method="POST" onSubmit="return validate()">
        <div class="row">
            <label>Name:</label>
            <input class="input-box" type="text" name="name" placeholder="developerswork"/>
        </div>
        <div class="row">
            <label>User Id:</label>
            <input class="input-box" type="text" name="username" placeholder="developerswork"/>
        </div>
        <div class="row">
            <label>Email Id:</label>
            <input class="input-box" type="text" name="email" placeholder="developerswork@developers.work"/>
        </div>
        <div class="row">
            <label>Mobile :</label>
            <input class="input-box" type="text" name="mobile" placeholder="+919999999999"/>
        </div>
        <div class="row">
            <label>Password :</label>
            <input class="input-box" type="password" name="password" placeholder="********"/>
        </div>
        <div class="row">
            <button class="btn" type="submit">REGISTER</button>
            <button class="btn" type="reset">RESET</button>
        </div>
    </form>
<?php
    }
?>
</body>
</html>