<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://gopinadh5g7.000webhostapp.com/componentStyle.css"/>
        <title>COOKIE LOGIN</title>
    </head>
    <body>
    <?php
        $EVERYTHING_FAILED = FALSE;
        if(!isset($_COOKIE['user1']))
            setcookie('user1',"pwd1");
        if(!isset($_COOKIE['user2']))
            setcookie('user2',"pwd2");
        if(!isset($_COOKIE['user3']))
            setcookie('user3',"pwd3");
        if(!isset($_COOKIE['user4']))
            setcookie('user4',"pwd4");

        if(isset($_POST["username"]) && isset($_POST["password"])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            // echo "$username <br/> $password <br/> $_COOKIE[$username]";
            if(isset($_COOKIE[$username])){
                if($password === $_COOKIE[$username])
                    echo "WELCOME, $username";
                else{
                    echo "You are not an authenticated user";
                    $EVERYTHING_FAILED = TRUE;
                }
            }
            else
                $EVERYTHING_FAILED = TRUE;
        }
        else
            $EVERYTHING_FAILED = TRUE;
        if($EVERYTHING_FAILED){
    ?>
            <form class="container box" method="POST" action="#">
                <div>
                    <input class="input-box" type="text" name="username" placeholder="developerswork"/>
                </div>
                <div>
                    <input class="input-box" type="password" name="password" placeholder="*******"/>
                </div>
                
                <div>
                    <input class="btn"  type="submit" value="LOGIN"/>
                    <input class="btn"  type="reset" value="RESET"/>
                </div>
            </form>
    <?php
        }
    ?>
    </body>
</html>